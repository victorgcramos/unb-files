/**
 * @file common.c
 * @brief Common operations library source
 * @authors Ismael Coelho Medeiros (14/0083162)
 *
 * This file contains all the function source codes which has the
 * signatures declared on the common.h file.
 */

#include "common.h"