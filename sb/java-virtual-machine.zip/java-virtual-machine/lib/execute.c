/**
 * @file execute.c
 * @brief Execution operations library source.
 * @authors Álvaro Torres Vieira (14/0079661)
 * @authors Ismael Coelho Medeiros (14/0083162)
 * @authors Victor Guedes Cordeiro Ramos (13/0145688)
 *
 * @todo Description
 */

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "execute.h"
#include "mem-areas.h"
#include "instruction.h"
#include "class.h"
#include "mem-manager.h"
#include "stack.h"
#include "common.h"
 
void execute(Class class) {
	
	// Inicia memória
	heap = initHeap(class);
	//printf("iniciou a heap\n");
	classLoader = initClassLoader(class);
	//printf("iniciou a Classloader\n");

	// Começa a executar
	MethodInfo* mainMethod = getMethod(&class, "main");
	
	// char* methodName = getUtf8FromConstantPool(mainMethod->nameIndex, class.constantPool,false);
	// printf("Got method: %s\n", methodName);

	int result = executeMethod(mainMethod, class);
	printf("Program exited with 0x%X\n", result);
}

MethodInfo* getMethod(Class *class, char *methodName){
	// printf("Procurando pelo método: %s\n", methodName);
	// Percorre todos os métodos até achar o método
	for (int i = 0; i < class->methodsCount; i++) {
		
		char* name = getUtf8FromConstantPool(class->methods[i].nameIndex, class->constantPool, false);
		char* descriptor = getUtf8FromConstantPool(class->methods[i].descriptorIndex, class->constantPool, false);
		
		if (strcmp(methodName, name) == 0){
			deallocate((void **) &name);
			deallocate((void **) &descriptor);
			return &class->methods[i];
		}

		deallocate((void **) &name);
		deallocate((void **) &descriptor);
	}

	return NULL;
}

CodeAttribute* getCodeAttr(MethodInfo* method, ConstPoolInfo* constantPool) {

	CodeAttribute* code = NULL;

	for (int attrIndex = 0; attrIndex < method->attributesCount; attrIndex++) {

		char* name = getUtf8FromConstantPool(method->attributes[attrIndex].attributeNameIndex, constantPool, false);

		if (strcmp(name, "Code") == 0) {
			code = (CodeAttribute*) method->attributes[attrIndex].specificInfo;

		}
	}

	return code;
}

int executeMethod(MethodInfo* method, Class class) {

	CodeAttribute* code = getCodeAttr(method, class.constantPool);

	// Inicia a pilha de operandos
	frame = initFrame(&class, code);
	// printf("Executando o Método: %s\n", getUtf8FromConstantPool(method->nameIndex, frame->currentClass->constantPool, false));

	//Aloca o frame na framestack
	if(frameStack == NULL){
		frameStack = initFrameStack(frame);
	}
	stkPush(&frameStack, frame);
	
	
	//Aloca o vetor de variáveis do frame
	frame->localVariables = (u4*) allocate(code->maxLocals * sizeof(u4));

	int codeIndex = 0;
	frame->codeIndexRef = &codeIndex;
	while (codeIndex < code->codeLength) {
        Instruction* instr = decode(code->code, &codeIndex);
		int result = instr->execute(instr);
		//printf("Executing: %s\n", instr->name);
        deallocate( (void**) &instr);

		if (result != 0) {
			return result;
		}
    }

	return 0;
}

Instruction* decode(u1* bytecode, int* offset) {

	int pc = (*offset);
	int opcode = bytecode[(*offset)++];

	switch (opcode) {

		// No arguments
		case AALOAD:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "aaload", &_aaload);
		case AASTORE:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "aastore", &_aastore);
		case ACONST_NULL:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "aconst_null", &_aconst_null);
		case ALOAD_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "aload_0", &_aload_0);
		case ALOAD_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "aload_1", &_aload_1);
		case ALOAD_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "aload_2", &_aload_2);
		case ALOAD_3:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "aload_3", &_aload_3);
		case ARETURN:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "areturn", &_areturn);
		//case ARRAYLENGTH:
		//case ASTORE_0:
		case ASTORE_1:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "astore_1", &_astore_1);
		//case ASTORE_2:
		/*case ASTORE_3:
		case ATHROW:
		case BALOAD:
		case BASTORE:
		case BREAKPOINT:
		case CALOAD:
		case CASTORE:
			instr->name = "arraylength";
		case D2F:
			instr->name = "arraylength";
		case D2I:
			instr->name = "arraylength";
		case D2L:
			instr->name = "arraylength";
		case DADD:
			instr->name = "arraylength";
		case DALOAD:
			instr->name = "arraylength";
		case DASTORE:
			instr->name = "arraylength";
		case DCMPG:
			instr->name = "arraylength";
		case DCMPL:
			instr->name = "arraylength";
		case DCONST_0:
			instr->name = "arraylength";
		case DCONST_1:
			instr->name = "arraylength";
		case DDIV:
			instr->name = "arraylength";*/
		case DLOAD_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dload_0", &_dload_0);
		case DLOAD_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dload_1", &_dload_1);
		case DLOAD_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dload_2", &_dload_2);
		case DLOAD_3:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dload_3", &_dload_3);
		case DMUL:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dmul", &_dmul);
		case DNEG:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dneg", &_dneg);
		case DREM:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "drem", &_drem);
		case DRETURN:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dreturn", &_dreturn);
		case DSTORE_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dstore_0", &_dstore_0);
		case DSTORE_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dsotre_1", &_dstore_1);
		case DSTORE_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dstore_2", &_dstore_2);
		case DSTORE_3:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dstore_3", &_dstore_3);
		case DSUB:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dsub", &_dsub);
		case DUP:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dup", &_dup);
		case DUP_X1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dup_x1", &_dup_x1);
		case DUP_X2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dup_x2", &_dup_x2);
		case DUP2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dup2", &_dup2); 
		case DUP2_X1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dup2_x1", &_dup2_x1);
		case DUP2_X2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "dup2_x2", &_dup2_x2);
		case F2D:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "f2d", &_f2d);
		case F2I:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "f2i", &_f2i);
		case F2L:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "f2l", &_f2l);
		case FADD:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fadd", &_fadd);
		case FALOAD:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "faload", &_faload);
		case FASTORE:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fastore", &_fastore);
		case FCMPG:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fcmpg", &_fcmpg);
		 case FCMPL:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fcmpl", &_fcmpl);
		case FCONST_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fconst_0", &_fconst_0);
		case FCONST_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fconst_1", &_fconst_1);
		case FCONST_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fconst_2", &_fconst_2);
		case FDIV:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fdiv", &_fdiv);
		case FLOAD_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fload_0", &_fload_0);
		case FLOAD_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fload_1", &_fload_1);
		case FLOAD_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fload_2", &_fload_2);
		case FLOAD_3:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fload_3", &_fload_3);
		case FMUL:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fmul", &_fmul);
		case FNEG:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fneg", &_fneg);
		case FREM:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "frem", &_frem);
		case FRETURN:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "freturn", &_freturn);
		case FSTORE_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fstore_0", &_fstore_0);
		case FSTORE_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fstore_1", &_fstore_1);
		case FSTORE_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fstore_2", &_fstore_2);
		case FSTORE_3:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fstore_3", &_fstore_3);
		case FSUB:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "fsub", &_fsub);
		case I2B:		
			return getNoArgsInstr(bytecode, offset, pc, opcode, "i2b", &_i2b);
		case I2C:		
			return getNoArgsInstr(bytecode, offset, pc, opcode, "i2c", &_i2c);
		case I2S:		
			return getNoArgsInstr(bytecode, offset, pc, opcode, "i2s", &_i2s); 
		case IADD:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iadd", &_iadd);
		case IALOAD:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iaload", &_iaload);
		case IAND:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iand", &_iand);
		case IASTORE:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iastore", &_iastore);
		case ICONST_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iconst_0", &_iconst_0);
		case ICONST_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iconst_1", &_iconst_1);
		case ICONST_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iconst_2", &_iconst_2);
		case ICONST_3:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iconst_3", &_iconst_3);
		case ICONST_4:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iconst_4", &_iconst_4);
		case ICONST_5:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iconst_5", &_iconst_5);
		case IDIV:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "idiv", &_idiv);	
		case ILOAD_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iload_0", &_iload_0);		
		case ILOAD_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iload_1", &_iload_1);
		case ILOAD_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iload_2", &_iload_2);
		case ILOAD_3:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iload_3", &_iload_3);
		case IMPDEP1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "impdep1", &_impdep1); 
		case IMPDEP2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "impdep2", &_impdep2);
		case IMUL:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "imul", &_imul);
		case INEG:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "ineg", &_ineg); 
		case IOR:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "ior", &_ior);  
		case IREM:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "irem", &_irem); 
		case IRETURN:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "ireturn", &_ireturn);
		case ISHL:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "ishl", &_ishl); 
		case ISHR:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "ishr", &_ishr); 
		case ISTORE_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode,"istore_0", &_istore_0);
		case ISTORE_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode,"istore_1", &_istore_1);
		case ISTORE_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode,"istore_2", &_istore_2);
		case ISTORE_3:
			return getNoArgsInstr(bytecode, offset, pc, opcode,"istore_3", &_istore_3); 
		case ISUB:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "isub", &_isub);  
		case IUSHR:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "iushr", &_iushr); 
		case IXOR:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "ixor", &_ixor); 
		//case L2R:
		//	return getNoArgsInstr(bytecode, offset, pc, opcode, "il2r", &_l2r); 
		//case L2F:
		//	return getNoArgsInstr(bytecode, offset, pc, opcode, "il2f", &_l2f); 
		//case L2I:
		//	return getNoArgsInstr(bytecode, offset, pc, opcode, "il2i", &_l2i); 
		case LADD:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "ladd", &_ladd);
		case LALOAD:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "laload", &_laload);
		case LAND:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "land", &_land);
		case LASTORE:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lastore", &_lastore);
		case LCMP:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lcmp", &_lcmp);
		case LCONST_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lconst_0", &_lconst_0); 
		case LCONST_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lconst_1", &_lconst_1);
		case LDIV:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "ldiv", &_ldiv);
		case LLOAD_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lload_0", &_lload_0);
		case LLOAD_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lload_1", &_lload_1);
		case LLOAD_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lload_2", &_lload_2);
		case LLOAD_3:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lload_3", &_lload_3); 
		case LMUL:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lmul", &_lmul);
		case LNEG:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lneg", &_lneg);
	
		case LREM:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lrem", &_lrem);
		case LRETURN:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lreturn", &_lreturn);
		case LSHL:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lshl", &_lshl);
		case LSHR:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lshr", &_lshr);
		case LSTORE_0:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lstore_0", &_lstore_0);
		case LSTORE_1:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lstore_1", &_lstore_1);
		case LSTORE_2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lstore_2", &_lstore_2);
		case LSTORE_3:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lstore_3", &_lstore_3);
			
		case LSUB:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lsub", &_lsub);
		case LUSHR:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "lushr", &_lushr);
		case MONITORENTER:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "monitorenter", &_monitorenter);
		case MONITOREXIT:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "monitorexit", &_monitorexit);
		case NOP:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "nop", &_nop);
		case POP:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "pop", &_pop);
		case POP2:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "pop2", &_pop2);
		case RETURN:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "return", &_return);
		case SALOAD:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "saload", &_saload);
		case SASTORE:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "sastore", &_sastore);
		case SWAP:
			return getNoArgsInstr(bytecode, offset, pc, opcode, "swap", &_swap);


		// One argument
		case BIPUSH:
			return getOneArgInstr(bytecode, offset, pc, opcode, "bipush", &_bipush);
		case LDC:
			return getOneArgInstr(bytecode, offset, pc, opcode, "ldc", &_ldc);
		//case RET:
		case ILOAD:
			return getOneArgInstr(bytecode, offset, pc, opcode, "iload", &_iload);
		case LLOAD:	
			return getOneArgInstr(bytecode, offset, pc, opcode, "lload", &_lload);
		case FLOAD:
			return getOneArgInstr(bytecode, offset, pc, opcode, "fload", &_fload);
		//case DLOAD:
		//case ALOAD:
		case ISTORE:
			return getOneArgInstr(bytecode, offset, pc, opcode, "istore", &_istore);
		case LSTORE:
			return getOneArgInstr(bytecode, offset, pc, opcode, "lstore", &_lstore);
		//case FSTORE:
		//case DSTORE:
		//case ASTORE:
		case NEWARRAY:
			return getOneArgInstr(bytecode, offset, pc, opcode, "newarray", &_newarray);

		// Two arguments
		case GOTO:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "goto", &_goto);
		//case IF_ACMPEQ:

		//	return getTwoArgsInstr(bytecode, offset, pc, opcode, "if_acmpeq", &_if_acmpeq);
		//case IF_ACMPNE:

		//	return getTwoArgsInstr(bytecode, offset, pc, opcode, "if_acmpne", &_if_acmpne);
		case IF_ICMPEQ:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "if_acmpeq", &_if_icmpeq);
		case IF_ICMPGE:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "if_acmpge", &_if_icmpge);
		case IF_ICMPGT:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "if_icmpgt", &_if_icmpgt);
		case IF_ICMPLE:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "if_acmple", &_if_icmple);
		case IF_ICMPLT:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "if_acmplt", &_if_icmplt);
		case IF_ICMPNE:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "if_acmpne", &_if_icmpne);
		

		case IFEQ:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "ifeq", &_ifeq);
		case IFGE:
			
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "ifge", &_ifge);
		case IFGT:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "ifgt", &_ifgt);

		case IFLT:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "iflt", &_iflt);
		case IFNE:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "ifne", &_ifne);
		case IFNONNULL:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "ifnonnull", &_ifnonnull);
		case IFNULL:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "ifnull", &_ifnull);
		case JSR:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "jsr", &_jsr);
		case SIPUSH:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "sipush", &_sipush);
		case IINC:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "iinc", &_iinc);
		case ANEWARRAY:

			return getTwoArgsInstr(bytecode, offset, pc, opcode, "anewarray", &_anewarray);
		case CHECKCAST:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "checkcast", &_checkcast);
		case GETFIELD:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "getfield", &_getfield);
		case GETSTATIC:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "getstatic", &_getstatic);
		case INSTANCEOF:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "instanceof", &_instanceof);
		case INVOKESPECIAL:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "invokespecial", &_invokespecial);
		case INVOKESTATIC:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "invokestatic", &_invokestatic);
		case INVOKEVIRTUAL:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "invokevirtual", &_invokevirtual);
		case LDC_W:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "ldc_w", &_ldc_w);
		case LDC2_W:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "ldc2_w", &_ldc2_w);
		case NEW:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "new", &_new);
		case PUTFIELD:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "putfield", &_putfield);
		case PUTSTATIC:
			return getTwoArgsInstr(bytecode, offset, pc, opcode, "putstatic", &_putstatic);

		// Three arguments
		//case MULTIANEWARRAY:

		// Four arguments
		//case GOTO_W:
		//case JSR_W:
		//case INVOKEINTERFACE:

		// Variable arguments
		//case WIDE

		default:
			return NULL;
	}
}

Instruction* getNoArgsInstr(u1* bytecode, int* offset, int pc, int opcode, char* name, int (*funct)(Instruction* instr)) {
	Instruction* instr = (Instruction*) allocate(sizeof(Instruction));
	instr->pc = pc;
	instr->opcode = opcode;
	instr->name = name;
	instr->argumentsCount = 0;
	instr->arguments = NULL;
	instr->execute = funct;
	return instr;
}

Instruction* getOneArgInstr(u1* bytecode, int* offset, int pc, int opcode, char* name, int (*funct)(Instruction* instr)) {
	Instruction* instr = (Instruction*) allocate(sizeof(Instruction));
	instr->pc = pc;
	instr->opcode = opcode;
	instr->name = name;
	instr->argumentsCount = 1;
	instr->arguments = (int8_t*) allocate(1 * sizeof(int8_t));
	instr->arguments[0] = (int8_t)readU1FromByteArray(bytecode, (*offset)++);
	instr->execute = funct;
	return instr;
}

Instruction* getTwoArgsInstr(u1* bytecode, int* offset, int pc, int opcode, char* name, int (*funct)(Instruction* instr)) {
	Instruction* instr = (Instruction*) allocate(sizeof(Instruction));
	instr->pc = pc;
	instr->opcode = opcode;
	instr->name = name;
	instr->argumentsCount = 2;
	instr->arguments = (int8_t*) allocate(2 * sizeof(int8_t));
	instr->arguments[0] = (int8_t)readU1FromByteArray(bytecode, (*offset)++);
	instr->arguments[1] = (int8_t)readU1FromByteArray(bytecode, (*offset)++);
	instr->execute = funct;
	return instr;
}




