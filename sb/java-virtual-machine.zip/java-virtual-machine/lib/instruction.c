/**
 * @file instruction.c
 * @brief Instruction operations and types library source.
 * @authors Ismael Coelho Medeiros (14/0083162)
 * @authors Victor Guedes Cordeiro Ramos (13/0145688)
 * @authors Arthur Henrique Aguiar Pereira (10/0054013)
 * @authors Álvaro Torres Vieira (14/0079661)
 * 
 * @todo Description
 */

#include <string.h>
#include "instruction.h"
#include "stack.h"
#include "mem-areas.h"
#include "mem-manager.h"
#include "common.h"
#include "class.h"
#include "execute.h"

u4 arrayref, indexinstr, high_bytes, low_bytes, objectRef;
u2 indexbyte;
u1 var;
int value1, value2, descriptor_count;
char cvalue1, cvalue2, t_arg;
short int svalue1, svalue2;
float fvalue1, fvalue2;
double dvalue1, dvalue2;
long long lvalue1, lvalue2;
char *string_arg;

int const_m1 = -1, const_0 = 0, const_1 = 1, const_2 = 2, const_3 = 3, const_4 = 4, const_5 = 5;
u1 lconst_0_low = 0x0, lconst_0_high = 0x0, lconst_1_low = 0x1, lconst_1_high = 0x0;
float fconst_0 = 0.0, fconst_1 = 1.0, fconst_2 = 2.0;
double dconst_0 = 0, dconst_1 = 1, dconst_2 = 2;



int _nop(Instruction* instr) {
    return 0;
}

int _aaload(Instruction* instr) {
    indexinstr = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    arrayref = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    return 0;
}



int _aastore(Instruction* instr) {
    value1 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    indexinstr = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    arrayref = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    return 0;
}


int _aconst_null(Instruction* instr) {
    stkPush(&(frame->operandStack),0);
    return 0;
}


int _aload_0(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[0])));
    return 0;
}


int _aload_1(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[1])));
    return 0;
}


int _aload_2(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[2])));
    return 0;
}


int _aload_3(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[2])));
    return 0;
}


int _areturn(Instruction* instr) {
    // objectRef = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    u1* element = ((u1*)stkPop(&(frame->operandStack))->elemRef);
    // Frame* frame = ((Frame*)stkPop(&(frameStack)));
    stkPop(&(frameStack));
    frame = ((Frame*)stkHead(frameStack));
    stkPush(&(frame->operandStack), element);
    return 0;
}

int _astore_0(Instruction* instr) {
    int32_t v1 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[0] = v1;
    return 0;
}

int _astore_1(Instruction* instr) {
    int32_t v1 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[1] = v1;
    return 0;
}

int _astore_2(Instruction* instr) {
    int32_t v1 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[2] = v1;
    return 0;
}

int _astore_3(Instruction* instr) {
    int32_t v1 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[3] = v1;
    return 0;
}

int _dstore_0(Instruction* instr){
    int32_t v1 = *((u4*)stkPop(&(frame->operandStack))->elemRef); //vetor de variaveis locais recebe high bytes
    int32_t v2 = *((u4*)stkPop(&(frame->operandStack))->elemRef); //vetor de variaveis locais recebe low bytes
    frame->localVariables[0] =  v1;
    frame->localVariables[1] =  v2;
    return 0;
}

int _dstore_1(Instruction* instr){
    int32_t v1 = *((u4*)stkPop(&(frame->operandStack))->elemRef); //vetor de variaveis locais recebe high bytes
    int32_t v2 = *((u4*)stkPop(&(frame->operandStack))->elemRef); //vetor de variaveis locais recebe low bytes
    frame->localVariables[1] = v1;
    frame->localVariables[2] = v2;

    printf("%d\n", v1);
    return 0;
}

int _dstore_2(Instruction* instr){
    int32_t v1 = *((u4*)stkPop(&(frame->operandStack))->elemRef); //vetor de variaveis locais recebe high bytes
    int32_t v2 = *((u4*)stkPop(&(frame->operandStack))->elemRef); //vetor de variaveis locais recebe low bytes
    frame->localVariables[2] = v1;
    frame->localVariables[3] = v2;
    return 0;
}

int _dstore_3(Instruction* instr){
    int32_t v1 = *((u4*)stkPop(&(frame->operandStack))->elemRef); //vetor de variaveis locais recebe high bytes
    int32_t v2 = *((u4*)stkPop(&(frame->operandStack))->elemRef); //vetor de variaveis locais recebe low bytes
    frame->localVariables[3] = v1;
    frame->localVariables[4] = v2;
    return 0;
}

int _dload_0(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[0])));
    stkPush(&(frame->operandStack),(&(frame->localVariables[1])));
    return 0;
}


int _dload_1(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[1])));
    stkPush(&(frame->operandStack),(&(frame->localVariables[2])));
    return 0;
}


int _dload_2(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[2])));
    stkPush(&(frame->operandStack),(&(frame->localVariables[3])));
    return 0;
}


int _dload_3(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[3])));
    stkPush(&(frame->operandStack),(&(frame->localVariables[4])));
    return 0;
}

int _dmul(Instruction* instr){
    return 0;
}

int _dneg(Instruction* instr){
    return 0;
}

int _drem(Instruction* instr){
    return 0;
}

int _dsub(Instruction* instr){
    return 0;
}

int _dreturn(Instruction* instr) {
    high_bytes = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    low_bytes = *((u4*)stkPop(&(frame->operandStack))->elemRef);

    Frame* frame = ((Frame*)stkPop(&(frameStack)));
    frame = ((Frame*)stkHead(frameStack));

    high_bytes = (u4) ((high_bytes >> 8) & 0x00000000ffffffff);
    low_bytes = (u4) (low_bytes & 0x00000000ffffffff);

    stkPush(&(frame->operandStack), (&(high_bytes)));
    stkPush(&(frame->operandStack), (&(low_bytes)));
    return 0;
}

int _dup(Instruction* instr) {
    void* primeiroElemento = stkHead(frame->operandStack);
    stkPush(&(frame->operandStack), primeiroElemento);
    return 0;
}

int _dup_x1(Instruction* instr){
    return 0;
}

int _dup_x2(Instruction* instr){
    return 0;
}

int _dup2(Instruction* instr) {
    void* primeiroElemento = stkPop(&(frame->operandStack));
    void* segundoElemento = stkPop(&(frame->operandStack));
    stkPush(&(frame->operandStack), segundoElemento);
    stkPush(&(frame->operandStack), primeiroElemento);
    stkPush(&(frame->operandStack), segundoElemento);
    stkPush(&(frame->operandStack), primeiroElemento);
    return 0;
}

int _dup2_x1(Instruction* instr){
    return 0;
}

int _dup2_x2(Instruction* instr){
    return 0;
}

int _f2d(Instruction* instr){
    return 0;
}

int _f2i(Instruction* instr){
    return 0;
}

int _f2l(Instruction* instr){
    return 0;
}

int _fadd(Instruction* instr){
    return 0;
}

int _faload(Instruction* instr){
    return 0;
}

int _fastore(Instruction* instr){
    return 0;
}

int _fcmpg(Instruction* instr){
    return 0;
}

int _fcmpl(Instruction* instr){
    return 0;
}


int _freturn(Instruction* instr) {
    fvalue1 = *((float*)stkPop(&(frame->operandStack))->elemRef);

    // Frame* frame = ((Frame*)stkPop(&(frameStack)));
    stkPop(&(frameStack));
    frame = ((Frame*)stkHead(frameStack));

    stkPush(&(frame->operandStack), (&(fvalue1)));
    return 0;
}

int _ireturn(Instruction* instr){
    value1 = *((int*)stkPop(&(frame->operandStack))->elemRef);

    stkPop(&(frameStack));
    frame = ((Frame*)stkHead(frameStack));

    stkPush(&(frame->operandStack), (&(fvalue1)));
    return 0;
}

int _pop(Instruction* instr) {
    stkPop(&frame->operandStack);
    return 0;
}


int _pop2(Instruction* instr) {
    stkPop(&frame->operandStack);
    stkPop(&frame->operandStack);
    return 0;
}

int _return(Instruction* instr) {
    stkPop(&(frameStack));
    frame = (Frame*) stkHead(frameStack);
    
    return 0;
}


int _bipush(Instruction* instr) {
    int32_t* byteRef = (int32_t*) allocate(sizeof(int32_t));
    *byteRef = (int32_t)instr->arguments[0];
    // printf("_bipush %d\n", *byteRef);
    stkPush(&(frame->operandStack), byteRef);
    return 0;
}

int _sipush(Instruction* instr) {

    int16_t s1 = ((instr->arguments[0] << 8) | (instr->arguments[1])); 
    value1 = (int) s1;
    stkPush(&(frame->operandStack), &value1);
    return 0;
}


int _ldc(Instruction* instr) {
    // indexbyte = instr->arguments[0];
    u4* bytes = NULL;
    if (frame->currentClass->constantPool[instr->arguments[0] - 1].tag == INTEGER){ //int
        
        bytes = &frame->currentClass->constantPool[instr->arguments[0] - 1].integerConst.bytes;
        stkPush(&(frame->operandStack), bytes);
    } else if (frame->currentClass->constantPool[instr->arguments[0] - 1].tag == FLOAT){ //float
        bytes = &frame->currentClass->constantPool[instr->arguments[0] - 1].floatConst.bytes;
        stkPush(&(frame->operandStack), bytes);
    }
    else if (frame->currentClass->constantPool[instr->arguments[0] - 1].tag == STRING){ //string
        char* string = getUtf8FromConstantPool(frame->currentClass->constantPool[instr->arguments[0] - 1].stringConst.stringIndex, frame->currentClass->constantPool, false);
        // printf("LDC: %s\n", string);
        stkPush(&(frame->operandStack), string);
    } else{
        printf("Erro: A entrada para o pool de constantes deve ser do tipo int, float ou referencia para alguma string.\n");
    }
    return 0;
}

/**
 * @brief 
 *
 * @todo Description
 *   
 */
int _getfield(Instruction* instr) {
/*

    indexbyte = instr->arguments[0];
    indexbyte = indexbyte << 8;
    indexbyte |= instr->arguments[1]; 


    u2 classIndex = frame->currentClass->constantPool[indexbyte].fieldRefConst.classIndex;
    u2 nameAndTypeIndex = frame->currentClass->constantPool[indexbyte].fieldRefConst.nameAndTypeIndex;
    u2 descriptorIndex = frame->currentClass->constantPool[nameAndTypeIndex-1].nameAndTypeConst.descriptorIndex; 
    u2 classNameIndex = frame->currentClass->constantPool[nameAndTypeIndex-1].nameAndTypeConst.nameIndex;

    char *type = getUtf8FromConstantPool(frame->currentClass->constantPool[descriptorIndex-1].utf8Const, frame->currentClass->constantPool, true);
    char *className = getUtf8FromConstantPool(frame->currentClass->constantPool[classNameIndex-1].utf8Const.bytes, frame->currentClass->constantPool, true);
 */  
    // next steps: procurar uma classe com o nome className. Se achou, dá um push no frame nessa classe
   /* 
    if ((type[0] =='J') || (type[0] == 'D')){
        //push 64 bits
    } else {
        stkPush(&frame, )
    }
*/
/*  *** CODIGO BASE ***
    name = className;
    type = type;
    
    while((field_index = maquina.retrieveFieldIndex(className, name, strlen(name), type, strlen(type))) == -1) {
        className = maquina.current_frame->current_class->getParentName(maquina.getClassByName(className));
    }

    aux = maquina.current_frame->pop();
    memcpy(objeto, &aux, sizeof(uint64_t));

    nameIndex = maquina.current_frame->current_class->fields_pool->fields[field_index].name_index;
    aux2 = maquina.getObjectField(objeto, nameIndex);


    if(type[0] == 'J' || type[0] == 'D') {
        maquina.current_frame->push2(aux2->value);
    } else {
        maquina.current_frame->push(aux2->value);
    } */
    return 0;
}


int _getstatic(Instruction* instr) {

    u2 attr = ((u2) instr->arguments[0]) << 8 | ((u2) instr->arguments[1]);

    char *string = getUtf8FromConstantPool(frame->currentClass->constantPool[frame->currentClass->constantPool[attr-1].fieldRefConst.nameAndTypeIndex - 1].nameAndTypeConst.nameIndex, frame->currentClass->constantPool, true);

    if (strcmp(string,"out") == 0){ 
        //printf("%s\n",stkpop(*frame->operandStack));
        //stkPush(&(frame->operandStack),0);
    } else {
        // TODO: Fazer o que o getstatic faz de verdade.
    }

    deallocate((void **) &string);
    return 0;
}


int _invokespecial(Instruction* instr) {

    MethodInfo* methodInvoke;
    Class* classAux;

    indexbyte = instr->arguments[0];
    indexbyte = indexbyte << 8;
    indexbyte |= instr->arguments[1];
    
    char* descriptor_name = getUtf8FromConstantPool(frame->currentClass->constantPool[frame->currentClass->constantPool[indexbyte - 1].methodRefConst.nameAndTypeIndex - 1].nameAndTypeConst.nameIndex, frame->currentClass->constantPool, false);
    char* className = getUtf8FromConstantPool(frame->currentClass->constantPool[frame->currentClass->constantPool[indexbyte - 1].methodRefConst.classIndex - 1].classConst.nameIndex, frame->currentClass->constantPool, false);

    // printf("Executando Método %s da classe %s\n",descriptor_name,className );
    classAux = findClassByName(classLoader, className);
    
    // char* nameaux = getUtf8FromConstantPool(classAux->constantPool[classAux->thisClass-1].classConst.nameIndex,classAux->constantPool,false);
    // printf("%s\n", nameaux);    

    methodInvoke = getMethod(classAux,descriptor_name);


    return executeMethod(methodInvoke, *classAux);
}


int _invokestatic(Instruction* instr) {
    MethodInfo* methodInvoke;

    indexbyte = instr->arguments[0];
    indexbyte = indexbyte << 8;
    indexbyte |= instr->arguments[1];
    
    // Pega o nome do descritor
    char* descriptor_name = getUtf8FromConstantPool(frame->currentClass->constantPool[frame->currentClass->constantPool[indexbyte - 1].methodRefConst.nameAndTypeIndex - 1].nameAndTypeConst.nameIndex, frame->currentClass->constantPool, false);
    
    //Chama o método do invoke
    methodInvoke = getMethod(frame->currentClass,descriptor_name);

    return executeMethod(methodInvoke, *(frame->currentClass));
}


int _invokevirtual(Instruction* instr) {
    int ret = 0;

    u2 attr0 = (u2) instr->arguments[0] << 8; 
    u2 attr1 = (u2) instr->arguments[1];
    u2 attr = attr0 | attr1;

    char *className = getUtf8FromConstantPool(frame->currentClass->constantPool[frame->currentClass->constantPool[attr - 1].methodRefConst.classIndex - 1].classConst.nameIndex, frame->currentClass->constantPool, false);
    // printf("debug string: %s\n", string);
    // getchar();
    char *methodName = getUtf8FromConstantPool(frame->currentClass->constantPool[frame->currentClass->constantPool[attr - 1].methodRefConst.nameAndTypeIndex - 1].nameAndTypeConst.nameIndex, frame->currentClass->constantPool, false);
    char *methodDesc = getUtf8FromConstantPool(frame->currentClass->constantPool[frame->currentClass->constantPool[attr - 1].methodRefConst.nameAndTypeIndex - 1].nameAndTypeConst.descriptorIndex, frame->currentClass->constantPool, false);
    // printf("desc: %s - name: %s - nameDesc: %s\n",methodDesc,string,nameDesc);

    if (strcmp(methodName,"println") == 0 || strcmp(methodName,"print") == 0 || strcmp(className,"java/io/PrintStream") == 0 ){ 

        if (strstr(methodDesc, "Ljava/lang/String;") != NULL) { // Print uma string

            printf("%s", (char*)(stkPop(&(frame->operandStack))->elemRef));

        } else if (strstr(methodDesc, "I") != NULL) { // Print um Inteiro

            printf("%d",*((int*)stkPop(&(frame->operandStack))->elemRef));

        } else if (strstr(methodDesc, "F") != NULL) { // Print um Float

            printf("%f",*((float*)stkPop(&(frame->operandStack))->elemRef));

        } else if (strstr(methodDesc, "C") != NULL) { // Print um Char ou Vetor de Char

            if (strstr(methodDesc, "[C") != NULL) {
                // @TODO: print [C no invoke virtual
            } else {
                printf("%c",*((int16_t*)stkPop(&(frame->operandStack))->elemRef));
            }

        } else if (strstr(methodDesc, "Z") != NULL) { // Print um Boolean

            if (stkPop(&(frame->operandStack))->elemRef) {
                printf("true");
            } else {
                printf("false");
            }

        } else if (strstr(methodDesc, "D") != NULL) { // Print um Double

            u4 valorLow = *((u4*)stkPop(&(frame->operandStack))->elemRef);
            u4 valorHigh = *((u4*)stkPop(&(frame->operandStack))->elemRef);
            printf("%f", (double)getDouble(valorLow,valorHigh));

        } else if (strstr(methodDesc, "J") != NULL) { // Print um Long

            u4 valorLow = *((u4*)stkPop(&(frame->operandStack))->elemRef);
            u4 valorHigh = *((u4*)stkPop(&(frame->operandStack))->elemRef);
            printf("%ld", (long)getLong(valorLow,valorHigh));

        }
    
        if (strcmp(methodName,"println") == 0) {
            printf("\n");
        }

    } else {
        
        // Execução real do InvokeVirtual
        MethodInfo* methodInvoke = getMethod(frame->currentClass, methodName);
        ret = executeMethod(methodInvoke, *(frame->currentClass));
    }

    deallocate((void **) &className);
    deallocate((void **) &methodName);
    deallocate((void **) &methodDesc);
    return ret;
}

int _iastore(Instruction* instr){
    // printf("_iastore\n");
    // u4 value = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    // indexinstr = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    // Array* array = ((Array*)stkPop(&(frame->operandStack))->elemRef);
    // *(array->values[indexinstr]) =  &value;
    return 0;
}

int _iaload(Instruction* instr){
    indexinstr = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    arrayref = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    return 0;
}

int laload(Instruction* instr){


    return 0;
}


int faload(Instruction* instr){


    return 0;
}

/**
 * @brief Load double from array.
 *
 * Both arrayref and index are popped from the operand stack.
 */

int daload(Instruction* instr){


    return 0;
}

/**
 * @brief Load byte from array.
 *
 * Both arrayref and index are popped from the operand stack.
 */

int baload(Instruction* instr){


    return 0;
}


int _iadd(Instruction* instr){
    value1 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    value2 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    int* resultRef = (int*) allocate(sizeof(int));
    (*resultRef) = value1 + value2;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}


int _isub(Instruction* instr){
    value1 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    value2 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    int* resultRef = (int*) allocate(sizeof(int));
    (*resultRef) = value2 - value1;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}


int _imul(Instruction* instr){
    value1 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    value2 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    int* resultRef = (int*) allocate(sizeof(int));
    (*resultRef) = value1 * value2;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}


int _idiv(Instruction* instr){
    value1 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    value2 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    int* resultRef = (int*) allocate(sizeof(int));
    (*resultRef) = value2 / value1;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}


int _irem(Instruction* instr){
    value2 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    value1 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    int* resultRef = (int*) allocate(sizeof(int));
    (*resultRef) = value1 - (value1 / value2) * value2;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}

int _ineg(Instruction* instr){
    value1 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    int* resultRef = (int*) allocate(sizeof(int));
    (*resultRef) = 0 - value1;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}


int _ishl(Instruction* instr){
    int32_t v2 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    int32_t v1 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    v2 = (v2 & 0x1f);
    v1 = (v1 << v2);
    int32_t* resultRef = (int32_t*) allocate(sizeof(int32_t));
    (*resultRef) = v1;

    stkPush(&(frame->operandStack), resultRef);
    return 0;
}


int _ishr(Instruction* instr){
    int32_t v2 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    int32_t v1 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    v2 = (v2 & 0x1f);
    v1 = (v1 >> v2);
    int32_t* resultRef = (int32_t*) allocate(sizeof(int32_t));
    (*resultRef) = v1;

    stkPush(&(frame->operandStack), resultRef);
    return 0;
}


int _iand(Instruction* instr){
    value1 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    value2 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    int* resultRef = (int*) allocate(sizeof(int));
    (*resultRef) = value1 & value2;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}


int _ior(Instruction* instr){
    value1 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    value2 = *((int*)stkPop(&(frame->operandStack))->elemRef);
    int* resultRef = (int*) allocate(sizeof(int));
    (*resultRef) = value1 | value2;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}

int _iconst_m1(Instruction* instr) {
    stkPush(&(frame->operandStack), &(const_m1));
    return 0;
}

int _iconst_0(Instruction* instr) {
    int32_t* byteRef = (int32_t*) allocate(sizeof(int32_t));
    *byteRef = (int32_t) const_0;
    stkPush(&(frame->operandStack), byteRef);
    return 0;
}

int _iconst_1(Instruction* instr) {
    int32_t* byteRef = (int32_t*) allocate(sizeof(int32_t));
    *byteRef = (int32_t) const_1;
    // printf("_iconst_1 %d\n", *byteRfe);
    stkPush(&(frame->operandStack), byteRef);
    return 0;
}

int _iconst_2(Instruction* instr) {
    int32_t* byteRef = (int32_t*) allocate(sizeof(int32_t));
    *byteRef = (int32_t) const_2;
    stkPush(&(frame->operandStack), byteRef);
    return 0;
}

int _iconst_3(Instruction* instr) {
    int32_t* byteRef = (int32_t*) allocate(sizeof(int32_t));
    *byteRef = (int32_t) const_3;
    stkPush(&(frame->operandStack), byteRef);
    return 0;
}

int _iconst_4(Instruction* instr) {

    stkPush(&(frame->operandStack), &(const_4));
    return 0;
}

int _iconst_5(Instruction* instr) {
    stkPush(&(frame->operandStack), &(const_5));
    return 0;
}

int _istore(Instruction* instr){
    frame->localVariables[instr->arguments[0]] = *((int16_t*)stkPop(&(frame->operandStack))->elemRef);
    return 0;
}

int _istore_0(Instruction* instr){
    value1 = *((int16_t*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[0] = value1;
    return 0;

}

int _istore_1(Instruction* instr){
    int32_t v1 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[1] = v1;
    return 0;

}

int _istore_2(Instruction* instr){
    int32_t v1 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[2] = v1;
    return 0;

}

int _istore_3(Instruction* instr){
    int32_t v1 = *((int32_t*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[3] = v1;
    return 0;

}

int _i2b(Instruction* instr){
    int8_t byte = *((int8_t*)stkPop(&(frame->operandStack)));
    value1 = (int32_t) byte;
    stkPush(&(frame->operandStack),(&(value1)));

    return 0;
}

int _i2c(Instruction* instr){
    int16_t char_aux = *((int16_t*)stkPop(&(frame->operandStack)));
    value1 = (uint32_t) char_aux;
    stkPush(&(frame->operandStack),(&(value1)));

    return 0;
}


int _i2s(Instruction* instr){
    svalue1 = *((int8_t*)stkPop(&(frame->operandStack)));
    value1 = (int32_t) svalue1;
    stkPush(&(frame->operandStack),(&(value1)));

    return 0;
}

int _lconst_0(Instruction* instr) {
    stkPush(&(frame->operandStack), &(lconst_0_high));
    stkPush(&(frame->operandStack), &(lconst_0_low));
    return 0;
}

int _lconst_1(Instruction* instr) {
    stkPush(&(frame->operandStack), &(lconst_1_high));
    stkPush(&(frame->operandStack), &(lconst_1_low));
    return 0;
}

int _fconst_0(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(fconst_0)));
    return 0;
}

int _fconst_1(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(fconst_1)));
    return 0;
}


int _fconst_2(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(fconst_2)));
    return 0;
}

int _fdiv(Instruction* instr){
    fvalue1 = *((float*)stkPop(&(frame->operandStack))->elemRef);
    fvalue2 = *((float*)stkPop(&(frame->operandStack))->elemRef);
    float* resultRef = (float*) allocate(sizeof(int));
    (*resultRef) = value1 / value2;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}

int _fmul(Instruction* instr){
    fvalue1 = *((float*)stkPop(&(frame->operandStack))->elemRef);
    fvalue2 = *((float*)stkPop(&(frame->operandStack))->elemRef);
    float* resultRef = (float*) allocate(sizeof(int));
    (*resultRef) = value1 * value2;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}

int _fneg(Instruction* instr){
    value1 = *((float*)stkPop(&(frame->operandStack))->elemRef);
    float* resultRef = (float*) allocate(sizeof(int));
    (*resultRef) = 0 - value1;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}

int _frem(Instruction* instr){
    value1 = *((float*)stkPop(&(frame->operandStack))->elemRef);
    value2 = *((float*)stkPop(&(frame->operandStack))->elemRef);
    float* resultRef = (float*) allocate(sizeof(int));
    (*resultRef) = value1 - (value1 / value2) * value2;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}


int _fsub(Instruction* instr){
    value1 = *((float*)stkPop(&(frame->operandStack))->elemRef);
    value2 = *((float*)stkPop(&(frame->operandStack))->elemRef);
    float* resultRef = (float*) allocate(sizeof(int));
    (*resultRef) = value1 - value2;
    stkPush(&(frame->operandStack), resultRef);
    return 0;
}


int _fstore(Instruction* instr){
    frame->localVariables[instr->arguments[0]] = *((float*)stkPop(&(frame->operandStack))->elemRef);
    return 0;
}

int _fstore_0(Instruction* instr){
    fvalue1 = *((u4*)stkPop(&(frame->operandStack)));
    frame->localVariables[0] = fvalue1;
    return 0;

}

int _fstore_1(Instruction* instr){
    fvalue1 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[1] = fvalue1;
    return 0;

}

int _fstore_2(Instruction* instr){
    fvalue1 = *((u4*)stkPop(&(frame->operandStack)));

    frame->localVariables[2] = fvalue1;
    return 0;

}

int _fstore_3(Instruction* instr){
    fvalue1 = *((u4*)stkPop(&(frame->operandStack)));

    frame->localVariables[3] = fvalue1;
    return 0;

}
/*!
    @brief Load double constant 0 in the operand stack

int _dconst_0() {
    low_bytes = dconst_0 & 0x00000000ffffffff;
    high_bytes = (dconst_0 >> 32) & 0x00000000ffffffff;
    stkPush(&(frame->operandStack),(&(high_bytes)));
    stkPush(&(frame->operandStack),(&(low_bytes)));
    return 0;
}
*/

/*!
    @brief Load double constant 1.0 in the operand stack


int _dconst_1() {
    low_bytes = dconst_1 & 0x00000000ffffffff;
    high_bytes = (dconst_1 >> 32) & 0x00000000ffffffff;
    stkPush(&(frame->operandStack),(&(high_bytes)));
    stkPush(&(frame->operandStack),(&(low_bytes)));
    return 0;
}
*/

/*!
    @brief Load double constant 2.0 in the operand stack

int _dconst_2() {    
    low_bytes = dconst_2 & 0x00000000ffffffff;
    high_bytes = (dconst_2 >> 32) & 0x00000000ffffffff;
    stkPush(&(frame->operandStack),(&(high_bytes)));
    stkPush(&(frame->operandStack),(&(low_bytes)));
    return 0;
}
*/

int _iload(Instruction* instr) {
    stkPush(&(frame->operandStack), (&(frame->localVariables[instr->arguments[0]])));
    return  0;
}

int _iload_0(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[0])));
    return 0;
}

int _iload_1(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[1])));
    return 0;
}

int _iload_2(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[2])));
    return 0;
}

int _iload_3(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[3])));
    return 0;
}

int _impdep1(Instruction* instr){
    return 0;
}

int _impdep2(Instruction* instr){
    return 0;
}

int _lload(Instruction* instr) {
    
    stkPush(&(frame->operandStack),(&(frame->localVariables[instr->arguments[0]]))); //empilha high_bytes
    stkPush(&(frame->operandStack),(&(frame->localVariables[instr->arguments[1]])));; //empilha low_bytes
    return 0;
}

int _lload_0(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[1]))); //empilha high_bytes
    stkPush(&(frame->operandStack),(&(frame->localVariables[0])));; //empilha low_bytes
    return 0;
}

int _lload_1(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[2]))); //empilha high_bytes
    stkPush(&(frame->operandStack),(&(frame->localVariables[1])));; //empilha low_bytes
    return 0;
}

int _lload_2(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[3]))); //empilha high_bytes
    stkPush(&(frame->operandStack),(&(frame->localVariables[2])));; //empilha low_bytes
    return 0;
}

int _lload_3(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[4]))); //empilha high_bytes
    stkPush(&(frame->operandStack),(&(frame->localVariables[3])));; //empilha low_bytes
    return 0;
}

int _fload(Instruction* instr) {
    stkPush(&(frame->operandStack), (&(frame->localVariables[instr->arguments[0]])));
    return  0;
}

int _fload_0(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[0]))); //empilha float
    return 0;
}

int _fload_1(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[1]))); //empilha float
    return 0;
}

int _fload_2(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[2]))); //empilha float
    return 0;
}

int _fload_3(Instruction* instr) {
    stkPush(&(frame->operandStack),(&(frame->localVariables[3]))); //empilha float
    return 0;
}

int _ldc2_w(Instruction* instr) {
    if (frame->currentClass->constantPool[instr->arguments[0] - 1].tag == LONG){
        stkPush(&(frame->operandStack), &(frame->currentClass->constantPool[instr->arguments[0] - 1].longConst.bytes.highBytes));
        stkPush(&(frame->operandStack), &(frame->currentClass->constantPool[instr->arguments[0] - 1].longConst.bytes.lowBytes));
    } else if (frame->currentClass->constantPool[instr->arguments[0] - 1].tag == DOUBLE){
        stkPush(&(frame->operandStack), &(frame->currentClass->constantPool[instr->arguments[0] - 1].doubleConst.bytes.highBytes));
        stkPush(&(frame->operandStack), &(frame->currentClass->constantPool[instr->arguments[0] - 1].doubleConst.bytes.lowBytes));
    } else {
        printf("Valores não são double ou long.\n");
    }
    return 0;
}

int _newarray(Instruction* instr) {
    
    // int count = *((int*)stkPop(&(frame->operandStack))->elemRef);
    
    // // Array newarray = *((Array*) allocate(sizeof(Array)));
    // // newarray.type = instr->arguments[0];
    // // newarray.size = count;
    
    // switch(instr->arguments[0]){
    //     // Boolean
    //     case 4:
    //         int *newarray = ((int*) allocate(sizeof(int)));
    //     break;
    //     // Char
    //     case 5:
    //         int *newarray = ((int*) allocate(sizeof(int)));
    //     break;
    //     // float
    //     case 6:
    //         int* newarray = ((int*) allocate(sizeof(int)));
    //     break;
    //     // double
    //     case 7:
    //         int* newarray = ((int*) allocate(sizeof(int)));
    //     break;
    //     // byte
    //     case 8:
    //         int* newarray = ((int*) allocate(sizeof(int)));
    //     break;
    //     // short
    //     case 9:
    //         int* newarray = ((int*) allocate(sizeof(int)));
    //     break;
    //     // int
    //     case 10:
    //         int* newarray = ((int*) allocate(sizeof(int)));
    //     break;
    //     // long
    //     case 11:
    //         int* newarray = ((int*) allocate(sizeof(int)));
    //     break;
    // }
    // // stkPush(&(frame->operandStack), &newarray);

    return 0;
}


int _new(Instruction* instr) {
    //u2 attr = (u2) instr->arguments[0] << 8 | instr->arguments[1]; 
    
    //char *nameIndex = getUtf8FromConstantPool(frame->currentClass->constantPool[attr-1].classConst.nameIndex, frame->currentClass->constantPool, true);
    //char * = getUtf8FromConstantPool(frame->currentClass->constantPool[nameIndex-1].utf8Const->bytes, frame->currentClass->constantPool, true);
    
    // @TODO tem que criar uma função para criar uma classe
    //class = loadClass(className);

    
    //stkPush(&(frame->operandStack), &(newObject(class)));

    return 0;
}

int _putfield(Instruction* instr) {

    return 0;
}

int _putstatic(Instruction* instr) {

    // u2 attr0 = (u2) instr->arguments[0] << 8; 
    // u2 attr1 = (u2) instr->arguments[1];

    // u2 attr = attr0 | attr1;

    // char *string = getUtf8FromConstantPool(class->constantPool[attr-1].nameAndTypeConst.nameIndex, class->constantPool, true));
    
    // //verifica se nao eh array
    // if (string != '[') {

    //     //Para 32bits
    //     if (strchr(string, 'Z') != NULL ||
    //             strchr(string, 'B') != NULL ||
    //             strchr(string, 'C') != NULL ||
    //             strchr(string, 'S') != NULL ||
    //             strchr(string, 'I') != NULL ||
    //             strchr(string, 'F') != NULL) {
    //         u4_temp = stkPop(&(frame->operandStack));
    //     } else {
    //         //para 64 bits
    //         u4 low_bytes = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    //         u4 high_bytes = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    //         u8 temp = high_bytes;
    //         temp = (temp << 32) + low_bytes;

    //     }
    // }
        
    return 0;
}

int _lstore(Instruction* instr) {
    frame->localVariables[instr->arguments[0]] = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[instr->arguments[0] + 1] = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    return 0;
}

int _lstore_0(Instruction* instr) {
    frame->localVariables[0] = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[1] = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    return 0;
}

int _lstore_1(Instruction* instr) {
    frame->localVariables[1] = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[2] = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    return 0;
}

int _lstore_2(Instruction* instr) {
    frame->localVariables[2] = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[3] = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    return 0;
}

int _lstore_3(Instruction* instr) {
    frame->localVariables[3] = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    frame->localVariables[4] = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    return 0;
}

int _goto(Instruction* instr) {
    u2 branchByte1 = ((u2)instr->arguments[0] << 8);
    u2 branchByte2 = (u2)instr->arguments[1];
    int16_t branch = branchByte1 | branchByte2;
    (*(frame->codeIndexRef)) += branch - 3;
    return 0;
}

int _if_icmpgt(Instruction* instr) {
    u2 branchByte1 = ((u2)instr->arguments[0] << 8);
    u2 branchByte2 = (u2)instr->arguments[1];
    u2 branch = branchByte1 | branchByte2;

    value2 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    value1 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    if(value1 > value2){
       (*(frame->codeIndexRef)) += branch - 3;
    }

    return 0;
}

int _if_icmpeq(Instruction* instr) {
    u2 branchByte1 = ((u2)instr->arguments[0] << 8);
    u2 branchByte2 = (u2)instr->arguments[1];
    u2 branch = branchByte1 | branchByte2;

    value2 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    value1 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
   
    if(value1 == value2){
       (*(frame->codeIndexRef)) += branch - 3;
    }

    return 0;
}

int _if_icmpne(Instruction* instr) {
    u2 branchByte1 = ((u2)instr->arguments[0] << 8);
    u2 branchByte2 = (u2)instr->arguments[1];
    u2 branch = branchByte1 | branchByte2;

    value2 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    value1 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
  
    if(value1 != value2){
       (*(frame->codeIndexRef)) += branch - 3;
    }

    return 0;
}

int _if_icmplt(Instruction* instr) {
    u2 branchByte1 = ((u2)instr->arguments[0] << 8);
    u2 branchByte2 = (u2)instr->arguments[1];
    u2 branch = branchByte1 | branchByte2;

    value2 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    value1 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
   
    if(value1 < value2){
       (*(frame->codeIndexRef)) += branch - 3;
    }

    return 0;
}

int _if_icmpge(Instruction* instr) {
    u2 branchByte1 = ((u2)instr->arguments[0] << 8);
    u2 branchByte2 = (u2)instr->arguments[1];
    u2 branch = branchByte1 | branchByte2;

    value2 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    value1 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    if(value1 >= value2){
       (*(frame->codeIndexRef)) += branch - 3;
    }

    return 0;
}

int _if_icmple(Instruction* instr) {
    u2 branchByte1 = ((u2)instr->arguments[0] << 8);
    u2 branchByte2 = (u2)instr->arguments[1];
    u2 branch = branchByte1 | branchByte2;

    value2 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
    value1 = *((u4*)stkPop(&(frame->operandStack))->elemRef);
   
    if(value1 <= value2){
       (*(frame->codeIndexRef)) += branch - 3;
    }

    return 0;
}
int _iinc(Instruction* instr) {
    value1 = frame->localVariables[(int)instr->arguments[0]];
    value2 = (int) instr->arguments[1];
    value1 += value2;
    frame->localVariables[(int)instr->arguments[0]] = value1;

    return 0;
}

int _ladd(Instruction* instr) {
    //u2 value1_low = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    //u2 value1_high = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    //u2 value2_low = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    //u2 value2_high = *((u1*)stkPop(&(frame->operandStack))->elemRef);
    //long long lvalue1 = ((long long)value1_high << 32) | (long long) value1_low;
    //long long lvalue2 = ((long long)value2_high << 32) | (long long) value2_low;
    //long long result = lvalue1 + lvalue2;
    //u2* result_high = (u2*) allocate(sizeof(u2));
    //(*result_high) = (u2)((result >> 32) & 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF);
    //stkPush(&(frame->operandStack), result_high);
    //u2* result_low = (u2*) allocate(sizeof(u2));
    //(*result_low) = (u2)(result & 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF);
    //stkPush(&(frame->operandStack), result_low);
    return 0;
}

int _ifeq(Instruction* instr){
        return 0;
    }

int _ifge(Instruction* instr){
        return 0;
    }

int _ifgt(Instruction* instr){
        return 0;
    }


int _iflt(Instruction* instr){
        return 0;
    }

int _ifne(Instruction* instr){
        return 0;
    }

int _ifnonnull(Instruction* instr){
        return 0;
    }

int _ifnull(Instruction* instr){
        return 0;
    }

int _jsr(Instruction* instr){
        return 0;
    }


int _instanceof(Instruction* instr){
        return 0;
    }

int _checkcast(Instruction* instr){
        return 0;
    }

int _anewarray(Instruction* instr){
        return 0;
    }
int _lsub(Instruction* instr){
        return 0;
    }

int _lushr(Instruction* instr){
        return 0;
    }
int _monitorenter(Instruction* instr){
        return 0;
    }
int _monitorexit(Instruction* instr){
        return 0;
    }
int _saload(Instruction* instr){
        return 0;
    }
int _sastore(Instruction* instr){
        return 0;
    }
int _swap(Instruction* instr){
        return 0;
    }
int _lmul(Instruction* instr){
        return 0;
    }
int _lneg(Instruction* instr){
        return 0;
    }
int _lor(Instruction* instr){
        return 0;
    }
int _rem(Instruction* instr){
        return 0;
    }
int _lreturn(Instruction* instr){
        return 0;
    }
int _lshl(Instruction* instr){
        return 0;
    }
int _lshr(Instruction* instr){
        return 0;
    }
int _ldiv(Instruction* instr){
        return 0;
    }
int _laload(Instruction* instr){
        return 0;
    }
int _lastore(Instruction* instr){
        return 0;
    }
int _lcmp(Instruction* instr){
        return 0;
    }
int _iushr(Instruction* instr){
        return 0;
    }
int _ixor(Instruction* instr){
        return 0;
    }
int _land(Instruction* instr){
    return 0;
}

int _ldc_w(Instruction* instr){
    return 0;
}


int _lrem(Instruction* instr){
    return 0;
}


