/**
 * @file class.c
 * @brief Classfile operations library source
 * @authors Ismael Coelho Medeiros (14/0083162)
 *
 * This file contains all the function source codes which has the
 * signatures declared on the class.h file.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "mem-manager.h"
#include "file.h"
#include "convert.h"
#include "class.h"

Class* readClassfile(FILE* fp) {
    int offset = 0;
    Class* class = (Class*) allocate(sizeof(Class));

    // Read magic
    class->magic = readU4BigEndian(fp, offset);
    offset += 4;

    // Read minor version
    class->minorVersion = readU2BigEndian(fp, offset);
    offset += 2;

    // Read major version
    class->majorVersion = readU2BigEndian(fp, offset);
    offset += 2;

    // Read constant pool count
    class->constantPoolCount = readU2BigEndian(fp, offset);
    offset += 2;

    // Read constant pool
    class->constantPool = readConstantPool(fp, &offset, class->constantPoolCount - 1);

    // Read access flags
    class->accessFlags = readU2BigEndian(fp, offset);
    offset += 2;

    // Read this class
    class->thisClass = readU2BigEndian(fp, offset);
    offset += 2;

    // Read super class
    class->superClass = readU2BigEndian(fp, offset);
    offset += 2;

    // Read interfaces count
    class->interfacesCount = readU2BigEndian(fp, offset);
    offset += 2;

    // Read interfaces
    class->interfaces = readInterfaces(fp, &offset, class->interfacesCount);

    // Read fields count
    class->fieldsCount = readU2BigEndian(fp, offset);
    offset += 2;
    
    // Read fields
    class->fields = readFields(fp, &offset, class->fieldsCount, class->constantPool);

    // Read methods count
    class->methodsCount = readU2BigEndian(fp, offset);
    offset += 2;

    // Read methods
    class->methods = readMethods(fp, &offset, class->methodsCount, class->constantPool);

    // Read attributes count
    class->attributesCount = readU2BigEndian(fp, offset);
    offset += 2;

    // Read attributes
    class->attributes = readAttributes(fp, &offset, class->attributesCount, class->constantPool);

    return class;
}

ConstPoolInfo* readConstantPool(FILE* fp, int* offset, u2 cpCount) {
    int cpIndex;

    // Allocate space for the costant pool
    ConstPoolInfo* cpInfo = (ConstPoolInfo*) allocate(cpCount * sizeof(ConstPoolInfo));

    for (cpIndex = 0; cpIndex < cpCount; cpIndex++) {

        // Read tag
        cpInfo[cpIndex].tag = readU1(fp, (*offset));
        (*offset)++;

        // Read cpInfo
        switch(cpInfo[cpIndex].tag) {
            // Read CONTANT_UTF8_Info
            case UTF8:
                cpInfo[cpIndex].utf8Const.length = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                cpInfo[cpIndex].utf8Const.bytes = (u1*) allocate((cpInfo[cpIndex].utf8Const.length) * sizeof(u1));
                for (int utf8Index = 0; utf8Index < (cpInfo[cpIndex].utf8Const.length); utf8Index++) {
                    cpInfo[cpIndex].utf8Const.bytes[utf8Index] = readU1(fp, (*offset));
                    (*offset)++;
                }
                break;

            // Read CONTANT_Integer_Info
            case INTEGER:
                cpInfo[cpIndex].integerConst.bytes = readU4BigEndian(fp, (*offset));
                (*offset) += 4;
                break;

            // Read CONTANT_Float_Info
            case FLOAT:
                cpInfo[cpIndex].floatConst.bytes = readU4BigEndian(fp, (*offset));
                (*offset) += 4;
                break;

            // Read CONTANT_Long_Info
            case LONG:
                cpInfo[cpIndex].longConst.bytes.highBytes = readU4BigEndian(fp, (*offset));
                (*offset) += 4;
                cpInfo[cpIndex].longConst.bytes.lowBytes = readU4BigEndian(fp, (*offset));
                (*offset) += 4;
                // This field are stored in two indexes
                cpIndex++;
                cpInfo[cpIndex].tag = LARGE_NUMERIC_CONTINUED;
                break;

            // Read CONTANT_Double_Info
            case DOUBLE:
                cpInfo[cpIndex].doubleConst.bytes.highBytes = readU4BigEndian(fp, (*offset));
                (*offset) += 4;
                cpInfo[cpIndex].doubleConst.bytes.lowBytes = readU4BigEndian(fp, (*offset));
                (*offset) += 4;
                // This field are stored in two indexes
                cpIndex++;
                cpInfo[cpIndex].tag = LARGE_NUMERIC_CONTINUED;
                break;

            // Read CONTANT_Class_Info
            case CLASS:
                cpInfo[cpIndex].classConst.nameIndex = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                break;

            // Read CONTANT_String_Info
            case STRING:
                cpInfo[cpIndex].stringConst.stringIndex = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                break;

            // Read CONTANT_Fieldref_Info
            case FIELD_REF:
                cpInfo[cpIndex].fieldRefConst.classIndex = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                cpInfo[cpIndex].fieldRefConst.nameAndTypeIndex = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                break;

            // Read CONTANT_Methodref_Info
            case METHOD_REF:
                cpInfo[cpIndex].methodRefConst.classIndex = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                cpInfo[cpIndex].methodRefConst.nameAndTypeIndex = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                break;

            // Read CONTANT_InterfaceMethodref_Info
            case INTERFACE_METHOD_REF:
                cpInfo[cpIndex].interfaceMethodRefConst.classIndex = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                cpInfo[cpIndex].interfaceMethodRefConst.nameAndTypeIndex = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                break;

            // Read CONTANT_NameAndType_Info
            case NAME_AND_TYPE:
                cpInfo[cpIndex].nameAndTypeConst.nameIndex = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                cpInfo[cpIndex].nameAndTypeConst.descriptorIndex = readU2BigEndian(fp, (*offset));
                (*offset) += 2;
                break;

            // Error while reading contant pool
            default:
                printf("Error while reading classfile on position: %ld\n", ftell(fp));
        }

    }

    return cpInfo;
}

u2* readInterfaces(FILE* fp, int* offset, u2 interfacesCount) {
    int interfacesIndex;

    u2* interfaces = (u2*) allocate(interfacesCount * sizeof(u2));

    for (interfacesIndex = 0; interfacesIndex < interfacesCount; interfacesIndex++) {
        interfaces[interfacesIndex] = readU2BigEndian(fp, (*offset));
        (*offset) += 2;
    }

    return interfaces;
}

FieldInfo* readFields(FILE* fp, int* offset, u2 fieldsCount, ConstPoolInfo* constantPool) {
    FieldInfo* field = (FieldInfo*) allocate(fieldsCount * sizeof(FieldInfo));

    for(int count = 0; count < fieldsCount; count++) {

        // Read access flags
        field[count].accessFlags = readU2BigEndian(fp, (*offset));
        (*offset) +=2;

        // Read name index
        field[count].nameIndex = readU2BigEndian(fp, (*offset));
        (*offset) +=2;

        // Read descriptor index
        field[count].descriptorIndex = readU2BigEndian(fp, (*offset));
        (*offset) +=2;

        // Read attributes count
        field[count].attributesCount = readU2BigEndian(fp, (*offset));
        (*offset) +=2;

        // Read attributes
        field[count].attributes = readAttributes(fp, offset, field[count].attributesCount, constantPool);
    }

    return field;

}

MethodInfo* readMethods(FILE* fp, int* offset, u2 methodsCount, ConstPoolInfo* constantPool) {
    MethodInfo* method = (MethodInfo*) allocate(methodsCount * sizeof(MethodInfo));

    for (int count = 0; count < methodsCount; count++) {

        // Read access flags
        method[count].accessFlags = readU2BigEndian(fp, (*offset));
        (*offset) +=2;
        
        // Read name index
        method[count].nameIndex = readU2BigEndian(fp, (*offset));
        (*offset) +=2;
        
        // Read descriptor index
        method[count].descriptorIndex = readU2BigEndian(fp, (*offset));
        (*offset) +=2;
        
        // Read attributes count
        method[count].attributesCount = readU2BigEndian(fp, (*offset));
        (*offset) +=2;
        
        // Read attributes
        method[count].attributes = readAttributes(fp, offset, method[count].attributesCount, constantPool);
    }

    return method;
}

AttributeInfo* readAttributes (FILE* fp, int* offset, u2 attributesCount, ConstPoolInfo* constantPool) {
    AttributeInfo* attribute = (AttributeInfo*) allocate(attributesCount * sizeof(AttributeInfo));

    for(int count = 0; count < attributesCount; count++) {
        
        // Read attribute name index
        attribute[count].attributeNameIndex = readU2BigEndian(fp, (*offset));
        (*offset) +=2;

        // Read attribute length
        attribute[count].attributeLength = readU4BigEndian(fp, (*offset));
        (*offset) +=4;

        // Read info
        attribute[count].info = (u1*) allocate(attribute[count].attributeLength * sizeof(u1));
        for (int attrIndex = 0; attrIndex < (attribute[count].attributeLength); attrIndex++) {
            attribute[count].info[attrIndex] = readU1(fp, (*offset));
            (*offset)++;
        }

        // Decode info
        attribute[count].specificInfo = decodeInfo(attribute[count], constantPool);
    }

    return attribute;
}

AttributeInfo* readAttributesFromByteArray(u1* info, int* offset, u2 attributesCount, ConstPoolInfo* constantPool) {
    AttributeInfo* attribute = (AttributeInfo*) allocate(attributesCount * sizeof(AttributeInfo));

    for (int count = 0; count < attributesCount; count++) {

        // Read attribute name index
        attribute[count].attributeNameIndex = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) +=2;

        // Read attribute length
        attribute[count].attributeLength = readU4BigEndianFromByteArray(info, (*offset));
        (*offset) +=4;
        
        if (attribute[count].attributeLength > 0) {

            // Read info
            attribute[count].info = (u1*) allocate((attribute[count].attributeLength) * sizeof(u1));
            for (int attrIndex = 0; attrIndex < (attribute[count].attributeLength); attrIndex++) {
                attribute[count].info[attrIndex] = readU1FromByteArray(info, (*offset));
                (*offset)++;
            }

            // Decode info
            attribute[count].specificInfo = decodeInfo(attribute[count], constantPool);
        }
    }

    return attribute;   
}

void* decodeInfo(AttributeInfo attribute, ConstPoolInfo* constantPool) {
    int offset = 0;
    void* specificInfo = NULL;

    // Get attribute name
    char* attributeName = getUtf8FromConstantPool(attribute.attributeNameIndex, constantPool, false);

    if (strcmp(attributeName, "ConstantValue") == 0) {

        // Allocate space
        ConstantValueAttribute* reference = (ConstantValueAttribute*) allocate(sizeof(ConstantValueAttribute));

        // Read contant value index
        reference->constantValueIndex = readU2BigEndianFromByteArray(attribute.info, offset);
        offset += 2;

        // Store reference
        specificInfo = reference;

    } else if (strcmp(attributeName, "Code") == 0) {

        CodeAttribute* reference = (CodeAttribute*) allocate(sizeof(CodeAttribute));

        // Read max stack
        reference->maxStack = readU2BigEndianFromByteArray(attribute.info, offset);
        offset += 2;

        // Read max locals
        reference->maxLocals = readU2BigEndianFromByteArray(attribute.info, offset);
        offset += 2;

        // Read code length
        reference->codeLength = readU4BigEndianFromByteArray(attribute.info, offset);
        offset += 4;

        // Read code
        reference->code = (u1*) allocate(reference->codeLength * sizeof(u1));
        for (int count = 0; count < reference->codeLength; count++) {
            reference->code[count] = readU1FromByteArray(attribute.info, offset);
            offset++;
        }

        // Read exception table length
        reference->exceptionTableLength = readU2BigEndianFromByteArray(attribute.info, offset);
        offset += 2;

        // Read exception table
        reference->exceptionTable = readExceptionTable(attribute.info, &offset, reference->exceptionTableLength);

        // Read attributes count
        reference->attributesCount = readU2BigEndianFromByteArray(attribute.info, offset);
        offset += 2;

        // Read attributes
        reference->attributes = readAttributesFromByteArray(attribute.info, &offset, reference->attributesCount, constantPool);

        // Store reference
        specificInfo = reference;

    } else if (strcmp(attributeName, "Deprecated") == 0) {

        // Don't have specific info

    } else if (strcmp(attributeName, "Exceptions") == 0) {

        ExceptionAttribute* reference = (ExceptionAttribute*) allocate(sizeof(ExceptionAttribute));

        // Read number of exception
        reference->numberOfExceptions = readU2BigEndianFromByteArray(attribute.info, offset);
        offset += 2;

        // Read exception index table
        reference->exceptionIndexTable = (u2*) allocate(reference->numberOfExceptions * sizeof(u2));
        for (int count = 0; count < reference->numberOfExceptions; count++) {
            reference->exceptionIndexTable[count] = readU2BigEndianFromByteArray(attribute.info, offset);
            offset += 2;
        }

        // Store reference
        specificInfo = reference;
        
    } else if (strcmp(attributeName, "InnerClasses") == 0) {

        InnerClassesAttribute* reference = (InnerClassesAttribute*) allocate(sizeof(InnerClassesAttribute));

        // Read number of classes
        reference->numberOfClasses = readU2BigEndianFromByteArray(attribute.info, offset);
        offset += 2;

        // Read classes
        reference->classes = readInnerClasses(attribute.info, &offset, reference->numberOfClasses);

        // Store reference
        specificInfo = reference;
        
    } else if (strcmp(attributeName, "SourceFile") == 0) {

        SourceFileAttribute* reference = (SourceFileAttribute*) allocate(sizeof(SourceFileAttribute));

        // Read source file index
        reference->sourceFileIndex = readU2BigEndianFromByteArray(attribute.info, offset);
        offset += 2;

        // Store reference
        specificInfo = reference;
        
    } else if (strcmp(attributeName, "LineNumberTable")) {

        LineNumberTableAttribute* reference = (LineNumberTableAttribute*) allocate(sizeof(LineNumberTableAttribute));

        // Read line number table length
        reference->lineNumberTableLength = readU2BigEndianFromByteArray(attribute.info, offset);
        offset += 2;

        // Read line number table
        reference->lineNumberTable = readLineNumberTable(attribute.info, &offset, reference->lineNumberTableLength);

        // Store reference
        specificInfo = reference;
        
    } else if (strcmp(attributeName, "LocalVariableTable") == 0) {

        LocalVariableTableAttribute* reference = (LocalVariableTableAttribute*) allocate(sizeof(LocalVariableTableAttribute));

        // Read local variable table length
        reference->localVariableTableLength = readU2BigEndianFromByteArray(attribute.info, offset);
        offset += 2;

        // Read local variable table length
        reference->localVariableTable = readLocalVariableTable(attribute.info, &offset, reference->localVariableTableLength);

        // Store reference
        specificInfo = reference;
        
    } // Ignore unknowm property

    deallocate( (void**) &attributeName );
    return specificInfo;
}

ExceptionTableEntry* readExceptionTable(u1* info, int* offset, int exceptionTableLength) {
    ExceptionTableEntry* exceptionTable = (ExceptionTableEntry*) allocate(exceptionTableLength * sizeof(ExceptionTableEntry));

    for (int count = 0; count < exceptionTableLength; count++) {

        // Read start_pc
        exceptionTable[count].startPc = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read end_pc
        exceptionTable[count].endPc = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read handler_pc
        exceptionTable[count].handlerPc = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read catch_type
        exceptionTable[count].catchType = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;
    }
    
    return exceptionTable;
}

InnerClass* readInnerClasses(u1* info, int* offset, int numberOfClasses) {
    InnerClass* innerClasses = (InnerClass*) allocate(numberOfClasses * sizeof(InnerClass));

    for (int count = 0; count < numberOfClasses; count++) {

        // Read inner_class_info_index
        innerClasses[count].innerClassInfoIndex = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read outer_class_info_index
        innerClasses[count].outerClassInfoIndex = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read inner_name_index
        innerClasses[count].innerNameIndex = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read inner_class_access_flags
        innerClasses[count].innerClassAccessFlags = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;
    }

    return innerClasses;
}

LineNumberTableEntry* readLineNumberTable(u1* info, int* offset, int lineNumberTableLength) {
    LineNumberTableEntry* lineNumberTable = (LineNumberTableEntry*) allocate(lineNumberTableLength * sizeof(LineNumberTableEntry));

    for (int count = 0; count < lineNumberTableLength; count++) {

        // Read start_pc
        lineNumberTable[count].startPc = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read line_number
        lineNumberTable[count].lineNumber = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;
    }

    return lineNumberTable;
}

LocalVariableTableEntry* readLocalVariableTable(u1* info, int* offset, int localVariableTableLength) {
    LocalVariableTableEntry* localVariableTable = (LocalVariableTableEntry*) allocate(localVariableTableLength * sizeof(LocalVariableTableEntry));

    for (int count = 0; count < localVariableTableLength; count++) {

        // Read start_pc
        localVariableTable[count].startPc = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read length
        localVariableTable[count].length = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read name_index
        localVariableTable[count].nameIndex = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read descriptor_index
        localVariableTable[count].descriptorIndex = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;

        // Read index
        localVariableTable[count].index = readU2BigEndianFromByteArray(info, (*offset));
        (*offset) += 2;
    }

    return localVariableTable;
}

char* getUtf8FromConstantPool(int index, ConstPoolInfo* constantPool, bool isRef) {
    if (index != 0) {
        return utf8ToString(constantPool[index - 1].utf8Const.bytes, constantPool[index - 1].utf8Const.length, isRef);
    } else {
        char* invalid = (char*) allocate(16 * sizeof(char));
        strcpy(invalid, "invalid contant");
        return invalid;
    }
    
}

u1 readU1(FILE* fp, int offset) {
    return readByte(fp, offset);
}

u2 readU2(FILE* fp, int offset) {
    return readWord(fp, offset);
}

u2 readU2BigEndian(FILE *fp, int offset) {
    return smallEndianToBigEndian2Bytes(readU2(fp, offset));
}

u4 readU4(FILE* fp, int offset) {
    return readDoubleWord(fp, offset);
}

u4 readU4BigEndian(FILE *fp, int offset) {
    return smallEndianToBigEndian4Bytes(readU4(fp, offset));
}

u1 readU1FromByteArray(u1* byteArr, int offset) {
    return byteArr[offset];
}

u2 readU2FromByteArray(u1* byteArr, int offset) {
    return ((u2) byteArr[offset + 1] << 8) | (u2) byteArr[offset];
}

u2 readU2BigEndianFromByteArray(u1* byteArr, int offset) {
    return smallEndianToBigEndian2Bytes(readU2FromByteArray(byteArr, offset));
}

u4 readU4FromByteArray(u1* byteArr, int offset) {
    return ((u4) byteArr[offset + 3] << 24) | ((u4) byteArr[offset + 2] << 16) | ((u4) byteArr[offset + 1] << 8) | (u4) byteArr[offset + 0]; 
}

u4 readU4BigEndianFromByteArray(u1* byteArr, int offset) {
    return smallEndianToBigEndian4Bytes(readU4FromByteArray(byteArr, offset));
}

double getDouble (u4 high, u4 low){
    double result;
    uint64_t aux;

    aux = (uint64_t)high;
    aux = aux << 32;
    aux |= (uint64_t)low;

    result = (double) aux;

    return result;

}

long getLong(u4 high, u4 low) {
    return ((uint64_t)high) << 32 | low;
}

void deallocateClass(Class** class) {

    if ((*class)->constantPool != NULL) {
        deallocate((void**) &((*class)->constantPool));
    }

    if ((*class)->interfaces != NULL) {
        deallocate((void**) &((*class)->interfaces));
    }

    if ((*class)->fieldsCount != 0 && (*class)->fields != NULL) {
        for (int i = 0; i < (*class)->fieldsCount; i++) {
            if ((*class)->fields[i].attributesCount != 0 && (*class)->fields[i].attributes != NULL) {
                for (int j = 0; j < (*class)->fields[i].attributesCount; j++) {
                    if ((*class)->fields[i].attributes[j].info != NULL) {
                        deallocate((void**) &((*class)->fields[i].attributes[j].info));
                    }
                    if ((*class)->methods[i].attributes[j].specificInfo != NULL) {
                        deallocate((void**) &((*class)->fields[i].attributes[j].specificInfo));
                    }
                }
                deallocate((void**) &((*class)->fields[i].attributes));
            }
        }
        deallocate((void**) &((*class)->fields));
    }

    if ((*class)->methodsCount != 0 && (*class)->methods != NULL) {
        for (int i = 0; i < (*class)->methodsCount; i++) {
            if ((*class)->methods[i].attributesCount != 0 && (*class)->methods[i].attributes != NULL) {
                for (int j = 0; j < (*class)->methods[i].attributesCount; j++) {
                    if ((*class)->methods[i].attributes[j].info != NULL) {
                        deallocate((void**) &((*class)->methods[i].attributes[j].info));
                    }
                    if ((*class)->methods[i].attributes[j].specificInfo != NULL) {
                        deallocate((void**) &((*class)->methods[i].attributes[j].specificInfo));
                    }
                }
                deallocate((void**) &((*class)->methods[i].attributes));
            }
        }
        deallocate((void**) &((*class)->methods));
    }

    if ((*class)->attributes != NULL) {
        for (int i = 0; i < (*class)->attributesCount; i++) {
            if ((*class)->attributes[i].info != NULL) {
                deallocate((void**) &((*class)->attributes[i].info));
            }
            if ((*class)->attributes[i].specificInfo != NULL) {
                deallocate((void**) &((*class)->attributes[i].specificInfo));
            }
        }
        deallocate((void**) &((*class)->attributes));
    }

    deallocate((void**) class);
}