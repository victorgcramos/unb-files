/**
 * @file mem-areas.h
 * @brief Declaration of memory areas used in JVM
 * @authors Álvaro Torres Vieira (14/0079661)
 * 
 * @todo Description
 */
#include <string.h>
#include "mem-areas.h"
#include "stack.h"
#include "mem-manager.h"

Object* newObject(Class class) {

	Object * object = (Object*)allocate(sizeof(Object));
	object->class = &class;
	object->runtimeConstantPool = *(class.constantPool);

	return object;
}

Class * loadClass(char* name) {
	/*
	if (strchr(name, '$')) error(E_DOLAR_NOT_SUPPORTED);
	int toReturn = -1;
	if ((toReturn = getClassIndex(name)) <= -1) {
		CLASS_LOADER* cl = initCLASS_LOADER();

		cl->load(cl, getClassPath(name));

		toReturn = maquina.method_area->classes_count;
		expandClassArray();
		maquina.method_area->classes[maquina.method_area->classes_count++] = cl->class;

		link(maquina.method_area->classes_count-1);
		initialize(maquina.method_area->classes_count-1);

 		loadParentClasses(); // insere em maquina.classes todas as classes pai ainda nao carregadas em maquina.clasess
 		loadInterfaces(cl->class); // insere em maquinas.interfaces todas as interfaces ainda nao carregadas em maquina.interfaces

		// free(cl);
	}

	// printf("\nsaiu loadClass: %s; toReturn: %d", name, toReturn);
	*/
	return 0;
}
Heap* initHeap(Class class) {
	Heap* heap = (Heap*) allocate(sizeof(Heap));

	heap->objectHeap = (Object*) allocate(sizeof(Object));
	heap->arrayHeap = NULL;

	heap->objectHeap[0].class = &class;
	heap->objectHeap[0].runtimeConstantPool = *(class.constantPool);

	return heap;
}


// MethodArea* initMethodArea() {
// 	MethodArea* methodArea = (MethodArea*) allocate(sizeof(MethodArea));

// 	methodArea->classes = (Class*) allocate(sizeof(Class));
// 	methodArea->interfaces = (Class*) allocate(sizeof(Class));
// 	methodArea->classesCount = 0;
// 	methodArea->interfacesCount = 0;

// 	return methodArea;
// }

Frame* initFrame(Class* currentClass, CodeAttribute* codeAttribute) {

	Frame* frame = (Frame*) allocate(sizeof(Frame));
	
	frame->localVariables = (u4*) allocate(codeAttribute->maxLocals * sizeof(u4));

	frame->operandStack = (Stack*) stkInit(0);

	frame->runtimeConstantPool = currentClass->constantPool;
	frame->codeAttribute = codeAttribute;
	frame->currentClass = currentClass;

	return frame;
}

Stack *initFrameStack(Frame *frame) {
	Stack *stack = stkInit(frame);
	return stack;
}

ClassLoader *initClassLoader(Class class) {
	int i;
	char *fileName;
	char *extension = ".class";
	char *filePath = "etc/";
	Class *newClass;
	FILE *fp;
	int classLoaderCount = 1;
	
	ClassLoader *classLoader = (ClassLoader*) allocate(sizeof(ClassLoader));
	classLoader[0].class = &class;
	for (i = 0; i < class.constantPoolCount; ++i)
	{
		// etc/HelloWorld.class
		// Se o elemento da constantpool é do tipo class, pega o nome do arquivo da constantpool que ele referencia, abre o arquivo
		// e coloca ele na lista ClassLoader
		
		if(class.constantPool[i].tag == CLASS){

			
			//pega o nome do ar
			char *className = getUtf8FromConstantPool(class.constantPool[i].classConst.nameIndex, class.constantPool, false);
		
			fileName = (char*) allocate((strlen(filePath) + strlen(className) + strlen(extension) + 1) * sizeof(char));
			strcpy(fileName, filePath);
			strcat(fileName, className);
			strcat(fileName, extension);
			
			
			fp = fopen(fileName,"rb");
			if (fp == NULL)
			{
				continue;
			}


			newClass = readClassfile(fp);


			// char *newClassName = getUtf8FromConstantPool(newClass->constantPool[newClass->thisClass-1].classConst.nameIndex, newClass->constantPool,false);
			// printf("Nome da classe aberta: %s\n", newClassName);
			// inserts new element on ClassLoader
			ClassLoader* newClassLoader = (ClassLoader*) allocate((++classLoaderCount) * sizeof(ClassLoader));
			for (int j = 0; j < classLoaderCount - 1; j++) {
				newClassLoader[j] = classLoader[j];
				// char *className = getUtf8FromConstantPool(newClassLoader[i].class->constantPool[classLoader[i].class->thisClass-1].classConst.nameIndex, newClassLoader[i].class->constantPool,false);
				// char *className = getUtf8FromConstantPool(classLoader[j].class->constantPool[classLoader[j].class->thisClass-1].classConst.nameIndex, classLoader[j].class->constantPool,false);
				// printf("%s\n", className);
			}
			newClassLoader[classLoaderCount - 1].class = newClass;
			deallocate((void**) &classLoader);
			classLoader = newClassLoader;

			// Close file
			closeFile(&fp);
		}
	}

	return classLoader;
}

Class* findClassByName (ClassLoader *classLoader, char* name){
	int tam = sizeof(*classLoader);
	int i;
	// percorre o array de classes
	for (i = 0; i < tam; ++i)
	{
		char *className = getUtf8FromConstantPool(classLoader[i].class->constantPool[classLoader[i].class->thisClass-1].classConst.nameIndex, classLoader[i].class->constantPool,false);
		// printf("%s\n", className);
		if(strcmp(className, name) == 0){
			// Se ele achar, retorna a classe
			return classLoader[i].class;
		}

	}
	return NULL;
}

