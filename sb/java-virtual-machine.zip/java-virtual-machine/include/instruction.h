/**
 * @file instruction.h
 * @brief Instruction operations and types library header.
 * @authors Ismael Coelho Medeiros (14/0083162)
 * @authors Victor Guedes Cordeiro Ramos (13/0145688)
 * @authors Arthur Henrique Aguiar Pereira (10/0054013)
 * @authors Álvaro Torres Vieira (14/0079661)
 * 
 * @todo Description
 */

#ifndef _INSTRUCTION_H
#define _INSTRUCTION_H

#include "common.h"

/**
 * @todo Brief
 * @todo Description
 */
enum {
    NOP = 0x0, ACONST_NULL = 0x1, ICONST_M1 = 0x2, ICONST_0 = 0x3, ICONST_1 = 0x4,
    ICONST_2 = 0x5, ICONST_3 = 0x6, ICONST_4 = 0x7, ICONST_5 = 0x8, LCONST_0 = 0x9,
    LCONST_1 = 0xA, FCONST_0 = 0xB, FCONST_1 = 0xC, FCONST_2 = 0xD, DCONST_0 = 0xE,
    DCONST_1 = 0xF, BIPUSH = 0x10, SIPUSH = 0x11, LDC = 0x12, LDC_W = 0x13,
    LDC2_W = 0x14, ILOAD = 0x15, LLOAD = 0x16, FLOAD = 0x17, DLOAD = 0x18, ALOAD = 0x19,
    ILOAD_0 = 0x1A, ILOAD_1 = 0x1B, ILOAD_2 = 0x1C, ILOAD_3 = 0x1D, LLOAD_0 = 0x1E,
    LLOAD_1 = 0x1F, LLOAD_2 = 0x20, LLOAD_3 = 0x21, FLOAD_0 = 0x22, FLOAD_1 = 0x23,
    FLOAD_2 = 0x24, FLOAD_3 = 0x25, DLOAD_0 = 0x26, DLOAD_1 = 0x27, DLOAD_2 = 0x28,
    DLOAD_3 = 0x29, ALOAD_0 = 0x2A, ALOAD_1 = 0x2B, ALOAD_2 = 0x2C, ALOAD_3 = 0x2D,
    IALOAD = 0x2E, LALOAD = 0x2F, FALOAD = 0x30, DALOAD = 0x31, AALOAD = 0x32,
    BALOAD = 0x33, CALOAD = 0x34, SALOAD = 0X35, ISTORE = 0x36, LSTORE = 0x37,
    FSTORE = 0x38, DSTORE = 0x39, ASTORE = 0x3A, ISTORE_0 = 0x3B, ISTORE_1 = 0x3C,
    ISTORE_2 = 0x3D, ISTORE_3 = 0x3E, LSTORE_0 = 0x3F, LSTORE_1 = 0x40, LSTORE_2 = 0x41,
    LSTORE_3 = 0x42, FSTORE_0 = 0x43, FSTORE_1 = 0x44, FSTORE_2 = 0x45, FSTORE_3 = 0x46, 
    DSTORE_0 = 0x47, DSTORE_1 = 0x48, DSTORE_2 = 0x49, DSTORE_3 = 0x4A, ASTORE_0 = 0x4B,
    ASTORE_1 = 0x4C, ASTORE_2 = 0x4D, ASTORE_3 = 0x4E, IASTORE = 0x4F, LASTORE = 0x50,
    FASTORE = 0x51, DASTORE = 0x52, AASTORE = 0x53, BASTORE = 0x54, CASTORE = 0x55,
    SASTORE = 0x56, POP = 0x57, POP2 = 0x58, DUP = 0x59, DUP_X1 = 0x5A, DUP_X2 = 0x5B,
    DUP2 = 0x5C, DUP2_X1 = 0x5D, DUP2_X2 = 0x5E, SWAP = 0x5F, IADD = 0x60, LADD = 0x61,
    FADD = 0x62, DADD = 0x63, ISUB = 0x64, LSUB = 0x65, FSUB = 0x66, DSUB = 0x67, 
    IMUL = 0x68, LMUL = 0x69, FMUL = 0x6A, DMUL = 0x6B, IDIV = 0x6C, LDIV = 0x6D, 
    FDIV = 0x6E, DDIV = 0x6F, IREM = 0x70, LREM = 0x71, FREM = 0x72, DREM = 0x73, 
    INEG = 0x74, LNEG = 0x75, FNEG = 0x76, DNEG = 0x77, ISHL = 0x78, LSHL = 0x79, 
    ISHR = 0x7A, LSHR = 0x7B, IUSHR = 0x7C, LUSHR = 0x7D, IAND = 0x7E, LAND = 0x7F, 
    IOR = 0x80, LOR = 0x81, IXOR = 0x82, LXOR = 0x83, IINC = 0x84, I2L = 0x85, F2D=0x8D, F2I=0X8B, F2L=0X8C, 
    D2F = 0x90, I2B = 0x91, I2C = 0x92, I2S = 0x93, LCMP = 0x94, FCMPL = 0x95,
    FCMPG = 0x96, DCMPL = 0x97, DCMPG = 0x98, IFEQ = 0x99, IFNE = 0x9A, IFLT = 0x9B, 
    IFGE = 0x9C, IFGT = 0x9D, IFLE = 0x9E, IF_ICMPEQ = 0x9F, IF_ICMPNE = 0xA0,
    IF_ICMPLT = 0xA1, IF_ICMPGE = 0xA2, IF_ICMPGT = 0xA3, IF_ICMPLE = 0xA4,
    IF_ACMPEQ = 0xA5, IF_ACMPNE = 0xA6, GOTO = 0xA7, JSR = 0xA8, RET = 0xA9, 
    TABLESWITCH = 0xAA, LOOKUPSWITCH = 0xAB, IRETURN = 0xAC, LRETURN = 0xAD, 
    FRETURN = 0xAE, DRETURN = 0xAF, ARETURN = 0xB0, RETURN = 0xB1, GETSTATIC = 0xB2,
    PUTSTATIC = 0xB3, GETFIELD = 0xB4, PUTFIELD = 0xB5, INVOKEVIRTUAL = 0xB6,
    INVOKESPECIAL = 0xB7, INVOKESTATIC = 0xB8, INVOKEINTERFACE = 0xB9,
    INVOKEDYNAMIC = 0xBA, NEW  = 0xBB, NEWARRAY = 0xBC, ANEWARRAY = 0xBD, 
    ARRAYLENGTH = 0xBE, ATHROW = 0xBF, CHECKCAST = 0xC0, INSTANCEOF = 0xC1,
    MONITORENTER = 0xC2, MONITOREXIT = 0xC3, WIDE = 0xC4, MULTIANEWARRAY = 0xC5,
    IFNULL = 0xC6, IFNONNULL = 0xC7, GOTO_W = 0xC8, JSR_W = 0xC9, BREAKPOINT = 0xCA,
    IMPDEP1 = 0xFE, IMPDEP2 = 0xFF
} byteCodeEnum;

/**
 * @todo Brief
 * @todo Description
 */
struct _instruction {
    int pc;
    int opcode;
    char* name;
    int argumentsCount;
    int8_t* arguments;
    int (*execute)(struct _instruction* instr);
};

/**
 * @todo Brief
 * @todo Description
 */
typedef struct _instruction Instruction;

/**
    @brief Do nothing.
*/
int _nop(Instruction* instr);

/**
 * @todo Brief
 * @todo Description
 */
int _aaload(Instruction* instr);

/**
 * @brief Store into reference array.
 *
 * The arrayref, index, and value are popped from the operand stack. 
 */
int _aastore(Instruction* instr);

/**
 * @brief Push null.
 *
 * Push the null object reference onto the operand stack. 
 */
int _aconst_null(Instruction* instr);

/**
 * @brief Load reference from local variable.
 *
 * The objectref in the local variable at 0 is pushed onto the operand stack. 
 */
int _aload_0(Instruction* instr);

/**
 * @brief Load reference from local variable.
 *
 * The objectref in the local variable at 1 is pushed onto the operand stack. 
 */
int _aload_1(Instruction* instr);

/**
 * @brief Load reference from local variable.
 *
 * The objectref in the local variable at 2 is pushed onto the operand stack. 
 */
int _aload_2(Instruction* instr);

/**
 * @brief Load reference from local variable.
 *
 * The objectref in the local variable at 3 is pushed onto the operand stack. 
 */
int _aload_3(Instruction* instr);

/**
 * @brief Return reference from method.
 *
 * Objectref is popped from the operand stack of the current frame 
 * and pushed onto the operand stack of the frame of the invoker.
 */
int _areturn(Instruction* instr);

/**
 * @brief Store reference into local variable.
 *
 * The objectref on the top of the operand stack is popped
 * and the value of the local variable at 0 is set to objectref. 
 */
int _astore_0(Instruction* instr);


/**
 * @brief Store reference into local variable.
 *
 * The objectref on the top of the operand stack is popped
 * and the value of the local variable at 1 is set to objectref. 
 */
int _astore_1(Instruction* instr);

/**
 * @brief Store reference into local variable.
 *
 * The objectref on the top of the operand stack is popped
 * and the value of the local variable at 2 is set to objectref. 
 */
int _astore_2(Instruction* instr);

/**
 * @brief Store reference into local variable.
 *
 * The objectref on the top of the operand stack is popped
 * and the value of the local variable at 3 is set to objectref. 
 */
int _astore_3(Instruction* instr);

int _dstore_0(Instruction* instr);

int _dstore_1(Instruction* instr);

int _dstore_2(Instruction* instr);

int _dstore_3(Instruction* instr);

int _dsub(Instruction* instr);

int _dload_0(Instruction* instr);

int _dload_1(Instruction* instr);

int _dload_2(Instruction* instr);

int _dload_3(Instruction* instr);

int _dmul(Instruction* instr);

int _dneg(Instruction* instr);

int _drem(Instruction* instr);


/**
 * @brief Return double from method.
 *
 * High bytes and Low Bytes are popped from the operand stack of the current frame
 * and undergoes value set conversion. The resulting value is pushed onto the 
 * operand stack of the frame of the invoker.
 */
int _dreturn(Instruction* instr);

/**
 * @brief Duplicate the top operand stack value.
 *
 * Duplicate the top value on the operand stack and 
 * push the duplicated value onto the operand stack.  
 */
int _dup(Instruction* instr);

int _dup_x1(Instruction* instr);

int _dup_x2(Instruction* instr);

/**
 * @brief Duplicate the top and the top-1 operand stack value.
 *
 * Duplicate the top value and the top-1 on the operand stack and 
 * push the duplicated values onto the operand stack.  
 */
int _dup2(Instruction* instr);

int _dup2_x1(Instruction* instr);

int _dup2_x2(Instruction* instr);

int _f2d(Instruction* instr);

int _f2i(Instruction* instr);

int _f2l(Instruction* instr);

int _fadd(Instruction* instr);

int _faload(Instruction* instr);

int _fastore(Instruction* instr);

int _fcmpg(Instruction* instr);

int _fcmpl(Instruction* instr);

/**
 * @brief Return float from method.
 *
 * Value is popped from the operand stack of the current frame and
 * is pushed onto the operand stack of the frame of the invoker.  
 */
int _freturn(Instruction* instr);

/**
 * @brief Pop the top operand stack value.
 *
 * @todo Description
 *   
 */
int _pop(Instruction* instr);

/**
 * @brief Pop the top and one more operand stack value.
 *
 * @todo Description
 *   
 */
int _pop2(Instruction* instr);

/**
 * @brief Return void from method.
 *
 * The interpreter then returns control to the invoker of the method,
 * reinstating the frame of the invoker.   
 */ 
int _return(Instruction* instr);

/**
 * @brief Push byte into the operand stack.
 *
 * The immediate byte is sign-extended to an int value. 
 * That value is pushed onto the operand stack. 
 */
int _bipush(Instruction* instr);


/**
 * @brief Push short into the operand stack.
 *
 * The immediate byte is sign-extended to an int value. 
 * That value is pushed onto the operand stack. 
 */
int _sipush(Instruction* instr);

/**
 * @brief Push item from run-time constant pool.
 *
 * If the run-time constant pool entry is a run-time constant of type int or float, 
 * the numeric value of that run-time constant is pushed onto the operand stack as an int or float, respectively.
 * Otherwise, if the run-time constant pool entry is a reference to an instance of class 
 * String representing a string literal, then a reference to that instance, value, is pushed onto the operand stack.
 */
int _ldc(Instruction* instr);

/**
 * @todo Brief
 * @todo Description
 */
int _getfield(Instruction* instr);

/**
 * @brief Get static field from class.
 *
 * The unsigned attr0 and attr1 are used to construct an index into the run-time constant pool 
 * of the current class, where the value of the index is (indexbyte1 << 8) | indexbyte2.  
 * The run-time constant pool item at that index must be a symbolic reference to a field, 
 * which gives the name and descriptor of the field as well as a symbolic reference to the class
 * or interface in which the field is to be found.
 */
int _getstatic(Instruction* instr);

/**
 * @brief Invoke instance method; special handling for superclass, private, and instance initialization method invocations.
 *
 * @todo Description
 *   
 */
int _invokespecial(Instruction* instr);

/**
 * @brief Invoke a class (static) method.
 *
 * @todo Description
 *   
 */
int _invokestatic(Instruction* instr);

/**
 * @brief Invoke instance method; dispatch based on class.
 *
 * @todo Description
 *   
 */
int _invokevirtual(Instruction* instr);

/**
 * @brief Store into int array
 *
 * Both arrayref, value and index are popped from the operand stack.
 */
int _iastore(Instruction* instr);

/**
 * @brief Load int from array.
 *
 * Both arrayref and index are popped from the operand stack.
 */
int _iaload(Instruction* instr);

/**
 * @brief Load long from array.
 *
 * Both arrayref and index are popped from the operand stack.
 */
int laload(Instruction* instr);

/**
 * @brief Load float from array.
 *
 * Both arrayref and index are popped from the operand stack.
 */
int faload(Instruction* instr);

/**
 * @brief Add int.
 *
 * The values are popped from the operand stack. The int result is value1 + value2. 
 * The result is pushed onto the operand stack.  
 */
int _iadd(Instruction* instr);

/**
 * @brief Subtract int.
 *
 * The values are popped from the operand stack. The int result is value1 - value2. 
 * The result is pushed onto the operand stack.   
 */
int _isub(Instruction* instr);

/**
 * @brief Multiply int.
 *
 * The values are popped from the operand stack. The int result is value1 * value2. 
 * The result is pushed onto the operand stack.   
 */
int _imul(Instruction* instr);

/**
 * @brief Divide int.
 *
 * The values are popped from the operand stack. The int result is value1 / value2. 
 * The result is pushed onto the operand stack.   
 */
int _idiv(Instruction* instr);

/**
 * @brief Remainder int.
 *
 * The values are popped from the operand stack. The int result is value1 - (value1 / value2) * value2.
 * The result is pushed onto the operand stack.   
 */
int _irem(Instruction* instr);

int _ireturn(Instruction* instr);

/**
 * @brief Negate int.
 *
 * The values are popped from the operand stack. The int result is the arithmetic negation of value, -value.
 * The result is pushed onto the operand stack.  
 */
int _ineg(Instruction* instr);

/**
 * @brief Shift left int.
 *
 * The values are popped from the operand stack. An int result is calculated by shifting 
 * value1 left by s bit positions, where s is the value of the low 5 bits of value2.   
 * The result is pushed onto the operand stack. 
 */
int _ishl(Instruction* instr);

/**
 * @brief Arithmetic shift right int.
 *
* The values are popped from the operand stack. An int result is calculated by shifting 
* value1 right by s bit positions, where s is the value of the low 5 bits of value2.   
* The result is pushed onto the operand stack.  
*/
int _ishr(Instruction* instr);

/**
 * @brief Boolean AND int.
 *
 * Both value1 and value2 must be of type int. They are popped from the operand stack.
 * An int result is calculated by taking the bitwise AND (conjunction) of value1 and value2. 
 * The result is pushed onto the operand stack.   
 */
int _iand(Instruction* instr);

/**
 * @brief Boolean OR int.
 *
 * Both value1 and value2 must be of type int. They are popped from the operand stack.
 * An int result is calculated by taking the bitwise OR of value1 and value2. 
 * The result is pushed onto the operand stack.  
 */
int _ior(Instruction* instr);

/**
 * @brief Push int constant.
 *
 * Push the int constant -1 onto the operand stack. 
 */
int _iconst_m1(Instruction* instr);

/**
 * @brief Push int constant.
 *
 * Push the int constant 0 onto the operand stack. 
 */
int _iconst_0(Instruction* instr);

/**
 * @brief Push int constant.
 *
 * Push the int constant 1 onto the operand stack. 
 */
int _iconst_1(Instruction* instr);

/**
 * @brief Push int constant.
 *
 * Push the int constant 2 onto the operand stack. 
 */
int _iconst_2(Instruction* instr);

/**
 * @brief Push int constant.
 *
 * Push the int constant 3 onto the operand stack. 
 */
int _iconst_3(Instruction* instr);

/**
 * @brief Push int constant.
 *
 * Push the int constant 4 onto the operand stack. 
 */
int _iconst_4(Instruction* instr);

/**
 * @brief Push int constant.
 *
 * Push the int constant 5 onto the operand stack. 
 */
int _iconst_5(Instruction* instr);

/**
 * @brief 
 */
int _iload(Instruction* instr);

/**
 * @brief Load int from local variable.
 *
 * The value of the local variable at 0 is pushed onto the operand stack. 
 */
int _iload_0(Instruction* instr);

/**
 * @brief Load int from local variable.
 *
 * The value of the local variable at 1 is pushed onto the operand stack. 
 */
int _iload_1(Instruction* instr);

/**
 * @brief Load int from local variable.
 *
 * The value of the local variable at 2 is pushed onto the operand stack. 
 */
int _iload_2(Instruction* instr);

/**
 * @brief Load int from local variable.
 *
 * The value of the local variable at 3 is pushed onto the operand stack. 
 */
int _iload_3(Instruction* instr);

int _impdep1(Instruction* instr);

int _impdep2(Instruction* instr);
/**
 * @brief Load long from local variable.
 *
 * The high bytes of the local variable at 1 is pushed onto the operand stack. 
 * The low bytes of the local variable at 0 is pushed onto the operand stack. 
 */
int _lload(Instruction* instr);
/**
 * @brief Load long from local variable.
 *
 * The high bytes of the local variable at 1 is pushed onto the operand stack. 
 * The low bytes of the local variable at 0 is pushed onto the operand stack. 
 */
int _lload_0(Instruction* instr);

/**
 * @brief Load long from local variable.
 *
 * The high bytes of the local variable at 2 is pushed onto the operand stack. 
 * The low bytes of the local variable at 1 is pushed onto the operand stack. 
 */
int _lload_1(Instruction* instr);

/**
 * @brief Load long from local variable.
 *
 * The high bytes of the local variable at 3 is pushed onto the operand stack. 
 * The low bytes of the local variable at 2 is pushed onto the operand stack. 
 */
int _lload_2(Instruction* instr);

/**
 * @brief Load long from local variable.
 *
 * The high bytes of the local variable at 4 is pushed onto the operand stack. 
 * The low bytes of the local variable at 3 is pushed onto the operand stack. 
 */
int _lload_3(Instruction* instr);

int _fload(Instruction* instr);

/**
 * @brief Load float from local variable.
 *
 *  The value of the local variable at 0 is pushed onto the operand stack. 
 */
int _fload_0(Instruction* instr);

/**
 * @brief Load float from local variable.
 *
 *  The value of the local variable at 1 is pushed onto the operand stack. 
 */
int _fload_1(Instruction* instr);

/**
 * @brief Load float from local variable.
 *
 *  The value of the local variable at 2 is pushed onto the operand stack. 
 */
int _fload_2(Instruction* instr);

/**
 * @brief Load float from local variable.
 *
 *  The value of the local variable at 3 is pushed onto the operand stack. 
 */
int _fload_3(Instruction* instr);

/**
 * @brief Push long or double from run-time constant pool.
 *
 * The run-time constant pool entry at the index must be a run-time constant of type long or double. 
 * The numeric value of that run-time constant is pushed onto the operand stack as a long or double, respectively. 
 */
int _ldc2_w(Instruction* instr);

/**
 * @todo Brief
 * @todo Description
 */
int _newarray(Instruction* instr);

/**
 * @todo Brief
 * @todo Description
 */
int _new(Instruction* instr);

/**
 * @todo Brief
 * @todo Description
 */
int _putfield(Instruction* instr);

/**
 * @todo Brief
 * @todo Description
 */
int _putstatic(Instruction* instr);

int _iload(Instruction* instr);

/**
 * @brief Store int into local variable
 *
 *  The tipe of the top of operand stack must be int. 
 *  If true, is set to local variable[index]; 
 */
int _istore(Instruction* instr);

/**
 * @brief Store int into local variable index 0
 *
 *  The tipe of the top of operand stack must be int. 
 *  If true, is set to local variable[0]; 
 */
int _istore_0(Instruction* instr);

/**
 * @brief Store int into local variable index 1
 *
 *  The tipe of the top of operand stack must be int. 
 *  If true, is set to local variable[1]; 
 */
int _istore_1(Instruction* instr);

/**
 * @brief Store int into local variable index 2
 *
 *  The tipe of the top of operand stack must be int. 
 *  If true, is set to local variable[2]; 
 */
int _istore_2(Instruction* instr);

/**
 * @brief Store int into local variable index 3
 *
 *  The tipe of the top of operand stack must be int. 
 *  If true, is set to local variable[3]; 
 */
int _istore_3(Instruction* instr);

/**
 * @brief Load long constant 0 in the operand stack.
 * 
 * Load long constant 0 in the operand stack.
 */
int _lconst_0(Instruction* instr);

/**
 * @brief Load long constant 1 in the operand stack.
 *
 * Load long constant 1 in the operand stack.
 */
int _lconst_1(Instruction* instr);

int _lstore(Instruction* instr);

int _lstore_0(Instruction* instr);

int _lstore_1(Instruction* instr);

int _lstore_2(Instruction* instr);

int _lstore_3(Instruction* instr);

int _goto(Instruction* instr);

/**
 * @brief Convert Int to byte
 *  Its a primitive truncation.
 *  It may loose information.
 */
int _i2b(Instruction* instr);

/**
 * @brief Convert Int to char
 *  Its a primitive truncation.
 *  It may loose information.
 */
int _i2c(Instruction* instr);

/**
 * @brief Convert Int to short
 *  Its a primitive truncation.
 *  It may loose information.
 */
int _i2s(Instruction* instr);


int _if_icmpgt(Instruction* instr);

int _iinc(Instruction* instr);

int _ladd(Instruction* instr);

/**
 * @brief Store float into local variable
 *
 *  The tipe of the top of operand stack must be float. 
 *  If true, is set to local variable[index]; 
 */
int _fstore(Instruction* instr);

/**
 * @brief Store float into local variable index 0
 *
 *  The tipe of the top of operand stack must be float. 
 *  If true, is set to local variable[0]; 
 */
int _fstore_0(Instruction* instr);

/**
 * @brief Store float into local variable index 1
 *
 *  The tipe of the top of operand stack must be float. 
 *  If true, is set to local variable[1]; 
 */
int _fstore_1(Instruction* instr);

/**
 * @brief Store float into local variable index 2
 *
 *  The tipe of the top of operand stack must be float. 
 *  If true, is set to local variable[2]; 
 */
int _fstore_2(Instruction* instr);

/**
 * @brief Store float into local variable index 3
 *
 *  The tipe of the top of operand stack must be float. 
 *  If true, is set to local variable[3]; 
 */
int _fstore_3(Instruction* instr);

/**
    @brief Load float constant 0.0 in the operand stack
*/
int _fconst_0(Instruction* instr);

/**
    @brief Load float constant 1.0 in the operand stack
*/
int _fconst_1(Instruction* instr);

/**
    @brief Load float constant 2.0 in the operand stack
*/
int _fconst_2(Instruction* instr);

/**
 * @brief Divide float.
 *
 * The values are popped from the operand stack. The float result is value1 / value2. 
 * The result is pushed onto the operand stack.   
 */
int _fdiv(Instruction* floattr);

/**
 * @brief Multiply float.
 *
 * The values are popped from the operand stack. The float result is value1 * value2. 
 * The result is pushed onto the operand stack.   
 */
int _fmul(Instruction* infloat);

/**
 * @brief Negate float.
 *
 * The value is popped from the operand stack. The float result is -value1. 
 * The result is pushed onto the operand stack.   
 */
int _fneg(Instruction* infloat);

/**
 * @brief Remainder float.
 *
 * The values are popped from the operand stack. The float result is value1 - (value1 / value2) * value2.
 * The result is pushed onto the operand stack.  
 */
int _frem(Instruction* instr);

/**
 * @brief Subtract float.
 *
 * The values are popped from the operand stack. The float result is value1 - value2. 
 * The result is pushed onto the operand stack.   
 */
int _fsub(Instruction* instr);

int _if_icmpeq(Instruction* instr);

int _if_icmpne(Instruction* instr);

int _if_icmplt(Instruction* instr);

int _if_icmpge(Instruction* instr);

int _if_icmple(Instruction* instr);

int _impdep1(Instruction* instr);

int _impdep2(Instruction* instr);

int _ifeq(Instruction* instr);

int _ifge(Instruction* instr);
    

int _ifgt(Instruction* instr);


int _iflt(Instruction* instr);

int _ifne(Instruction* instr);

int _ifnonnull(Instruction* instr);
    

int _ifnull(Instruction* instr);

int _ireturn(Instruction* instr);

int _jsr(Instruction* instr);

    
int _instanceof(Instruction* instr);
    
int _checkcast(Instruction* instr);

int _anewarray(Instruction* instr);

int _lsub(Instruction* instr);

int _lushr(Instruction* instr);

int _monitorenter(Instruction* instr);

int _monitorexit(Instruction* instr);

int _saload(Instruction* instr);

int _sastore(Instruction* instr);

int _swap(Instruction* instr);

int _lmul(Instruction* instr);

int _lneg(Instruction* instr);

int _lor(Instruction* instr);

int _rem(Instruction* instr);

int _lreturn(Instruction* instr);

int _lshl(Instruction* instr);

int _lshr(Instruction* instr);

int _ldiv(Instruction* instr);

int _laload(Instruction* instr);

int _lastore(Instruction* instr);

int _lrem(Instruction* instr);

int _lcmp(Instruction* instr);

int _iushr(Instruction* instr);

int _ixor(Instruction* instr);

int _land(Instruction* instr);

int _ldc_w(Instruction* instr);

    
#endif // _INSTRUCTION_H