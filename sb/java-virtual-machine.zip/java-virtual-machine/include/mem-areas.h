/**
 * @file mem-areas.h
 * @brief Declaration of memory areas used in JVM
 * @authors Álvaro Torres Vieira (14/0079661)
 * 
 * TODO: DOCUMENTATION & DESCRIPTION
 */

 #ifndef _MEM_AREAS_H
 #define _MEM_AREAS_H

 #include "stack.h"
 #include "file.h"
 #include "class.h"
 #include "common.h"




/**
 * TODO: @brief 
 *  
 *	...
 */

struct _array {
	u4 size;
	u4 type;
	u4 elementSize;	
	void** values;
};

/**
 * TODO:  @brief 
 *  
 *	...
 */

typedef struct _array Array;

/**
 * TODO:  @brief 
 *  
 *	...
 */

struct _object{
	Class *class;
	ConstPoolInfo runtimeConstantPool;
};

/**
 * TODO:  @brief 
 *  
 *	...
 */

typedef struct _object Object;

/**
 * TODO:  @brief 
 *  
 *	...
 */




struct _heap{
	Array *arrayHeap;
	Object *objectHeap;
};

typedef struct _heap Heap;
/**
 * TODO: @brief 
 *  
 *	...
 */

// struct _method_area{

// 		Class *classes, *interfaces;
// 		u4 classesCount, interfacesCount;

// 	// O QUE DEVE TER:
// 	//ConstPoolInfo *constantPoolMethodArea;
// 	//attributeInfo *attributeInfoMethodArea; // não sei se é a struct certa! Fiquei confuso no class.h
// 	//methodInfo *methodInfoMethodArea;
// 	//codigo de metododos
// 	//codigo de construtores

// };

// /**
//  * @todo Brief
//  * @todo Description
//  */
// typedef struct _method_area MethodArea;

/**
 * TODO:  @brief 
 *  
 *	...
 */

struct _frame {

/* Um novo frame é criado cada vez que um método é chamado. 
O frame é destruído quando o método que o chamou encerra normalmente ou abruptamente (lança uma exceção). 
É alocado a partir da pilha da JVM da thread que o criou. 
Cada frame possui seu próprio array de variáveis locais, sua pilha de operandos 
e uma referência para o pool de constantes da classe do método corrente. 
*/

	u4 *localVariables;
	Stack *operandStack;
	ConstPoolInfo *runtimeConstantPool;
	Class *currentClass;
	CodeAttribute *codeAttribute;
	int* codeIndexRef;
	
};

/**
 * TODO: @brief 
 *  
 *	...
 */

typedef struct  _frame Frame;

/**
 * TODO: @brief 
 *  
 *	...
 */

struct _instructions_area{


};

/**
 * TODO: @brief 
 *  
 *	...
 */

typedef struct _instructions_area InstructionsArea;

/**
* Essa estutura contém todas as informações a respeito dos .class que ele tem como dependencia
*	O ClassLoader é uma lista de class que são carregados pela jvm
*/

struct _class_loader{
	Class *class;
};

typedef struct _class_loader ClassLoader;

/**
 * @todo Brief
 * @todo Description
 * @todo Return
 */

Object * newObject(Class class);

/**
 * @todo Brief
 * @todo Description
 * @todo Return
 */
Heap * initHeap();

// /**
//  * @todo Brief
//  * @todo Description
//  * @todo Return
//  */
// MethodArea * initMethodArea();

/**
 * @todo Brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
Frame* initFrame(Class* class, CodeAttribute* codeAttribute);

/**
 * @todo Brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
Stack *initFrameStack(Frame *frame);

/**
 * @todo Brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
ClassLoader *initClassLoader(Class class);

/**
 * @todo Brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
Class* findClassByName (ClassLoader *classLoader, char* name);

Heap *heap;
Frame *frame;
// MethodArea *methodArea;
Stack *frameStack;
ClassLoader *classLoader;

#endif // _MEM_AREAS_H
