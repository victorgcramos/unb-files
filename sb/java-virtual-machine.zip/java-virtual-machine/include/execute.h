/**
 * @file execute.h
 * @brief Execution operations library header.
 * @authors Álvaro Torres Vieira (14/0079661)
 * @authors Ismael Coelho Medeiros (14/0083162)
 * @authors Victor Guedes Cordeiro Ramos (13/0145688)
 * @authors Arthur Henrique Aguiar Pereira (10/0054013)
 * 
 * @todo Description
 */

#ifndef _EXECUTE_H
#define _EXECUTE_H

#include "class.h"
#include "instruction.h"

/**
 * @ Brief initiate memory areas and run the program
 * @ Description 
 * This function calls the functions initHeap, initClassLoader, 
 * then it finds the main method and starts executing the methods.
 * After that, it prints the exit code after running all the methods
 * @ Parameters Global Struct Class
 * @ Return void
 */
void execute(Class class);

/** 
 * @ Brief Search for a specific method name in the ConstatPool
 * @ Description 
 * The function is a loop in all the nameIndex and Descriptor Index from the Constant Pool.
 * It runs all the names until it finds the one with methodName. If it finds, returns its address. Otherwise, returns null.
 * @ Parameters Global Struct class and string with the name of the method.
 * @ Return MethodInfo*
 */
MethodInfo* getMethod(Class *class, char *methodName);

/** 
 * @ Brief Search for code Attribute in the ConstatPool and in the struct MethodInfo
 * @ Description 
 * The function gets the Code from the struct Methods compairing the AttributeNameIndex with the word "Code"
 * @ Parameters Struct MethodInfo and the ConstantPool.
 * @ Return Struct CodeAttribute*
 */

CodeAttribute* getCodeAttr(MethodInfo* method, ConstPoolInfo* constantPool);

/**
 * @Brief Allocates and initializes the methodframe and execute the instructions from the code.
 * @Description
 * It firts call the getCodeAttr to make the CodeAttr local. Then, allocates and pushes into the stakc the frame related to the
 * method that will be executed. It iniciates the variables from the frame and run all the codes lines with specific structions. 
 * It returns 0 if the execution was correct and another integer otherwise.
 * @Parameters MethodInfo and Global Struct class
 * @Return Integer with the exit code
 */
int executeMethod(MethodInfo* method, Class class);

/**
 * @Brief From the offset (Program Counter) it returns the instruction to be executed.
 * @Description 
 * The function contains an switch case function containing all the structions implemented. It returns a call to another
 * function, depending on the type of the instruction: if it was no arguments, one argument or 2 arguments. This call is to 
 * initialize the variables inside de instruction struct.
 * @Parameters char *byteCode and an int offset 
 * @Return Struct instructions with their arguments.
 */
Instruction* decode(u1* byteCode, int* offset);

/**
 * @Brief It initializes the struct instruction with all its variables. In this case, the arguments variable it set to NULL. 
 * @Description
 * The function simply allocates memory space for the instructions and sets its variables with the parameters passed throught the 
 * the function parameters. The arguments (2 byte array) are set to null because there is no need to use. 
 * The funct variable recieves the instruction to be executed.
 * @Parameters char *bytecode, int offset, int pc, int opcode, char name(from the instruction), int (*func) Instruction
 * @Return Struct Instruction with all the arguments initialized
 */
Instruction* getNoArgsInstr(u1* bytecode, int* offset, int pc, int opcode, char* name, int (*funct)(Instruction* instr));


/**
 * @Brief It initializes the struct instruction with all its variables. In this case, the arguments[0] is one byte read from the bytecode. 
 * @Description
 * The function simply allocates memory space for the instructions and sets its variables with the parameters passed throught the 
 * the function parameters. There is only one argument that needs to be used, so the arguments[0] recieves from the bytecode+offset
 * one byte. The funct variable recieves the instruction to be executed.
 * @Parameters char *bytecode, int offset, int pc, int opcode, char name(from the instruction), int (*func) Instruction
 * @Return Struct Instruction with all the arguments initialized
 */
Instruction* getOneArgInstr(u1* bytecode, int* offset, int pc, int opcode, char* name, int (*funct)(Instruction* instr));

/**
 * @Brief It initializes the struct instruction with all its variables. In this case, the arguments[0] and arguments[1] are one byte read from the bytecode each. 
 * @Description
 * The function simply allocates memory space for the instructions and sets its variables with the parameters passed throught the 
 * the function parameters. The instruction needs 2 arguments, so the arguments[0] recieves from the bytecode+offset
 * one byte and and arguments[1] recieves from the bytecode+offset+1 one byte aswell.
 * The funct variable recieves the instruction to be executed.
 * @Parameters char *bytecode, int offset, int pc, int opcode, char name(from the instruction), int (*func) Instruction
 * @Return Struct Instruction with all the arguments initialized
 */
Instruction* getTwoArgsInstr(u1* bytecode, int* offset, int pc, int opcode, char* name, int (*funct)(Instruction* instr));

#endif // _EXECUTE_H