/**
 * @file class.h
 * @brief Classfile operations and types library header.
 * @authors Ismael Coelho Medeiros (14/0083162)
 * @authors Victor Guedes Cordeiro Ramos (13/0145688)
 * @authors Arthur Henrique Aguiar Pereira (10/0054013)
 * @authors Álvaro Torres Vieira (14/0079661)
 * @todo Description
 */

#ifndef _CLASS_H
#define _CLASS_H

#include <stdbool.h>
#include "common.h"

/**
 * @brief Enum with a type name assignment with the bytecode number that represents that name.
 */
enum {
    LARGE_NUMERIC_CONTINUED = 0,
    UTF8 = 1,
    INTEGER = 3,
    FLOAT = 4,
    LONG = 5,
    DOUBLE = 6,
    CLASS = 7,
    STRING = 8,
    FIELD_REF = 9,
    METHOD_REF = 10,
    INTERFACE_METHOD_REF = 11,
    NAME_AND_TYPE = 12
} ContantsInfo;

/**
 * @brief Structure of the constant pool, separated by type.
 */
struct _const_pool_info {
    /**
     * @brief Field tag from the constant pool.
     * 
     * Field tag is common for all types.
     */
    u1 tag;
    /**
     * @brief Union of structs containing the types within the constant pool.
     * 
     * Each type has its own structure.
     */
    union {
        /**
         * @brief Class type.
         * 
         * Contains the name index from the class.
         */
        struct {
            u2 nameIndex;
        } classConst;
        /**
         * @brief FieldRef type.
         * 
         * Contains the class index and the name and type index from the FieldRef.
         */
        struct {
            u2 classIndex;
            u2 nameAndTypeIndex;
        } fieldRefConst;
        /**
         * @brief Name and Type type.
         * 
         * Contains the name index and the descriptor index.
         */
        struct {
            u2 nameIndex;
            u2 descriptorIndex;
        } nameAndTypeConst;
        /**
         * @brief UTF8 type.
         * 
         * Contains the lenght and the pointer for bytes from the UTF8.
         */
        struct {
            u2 length;
            u1* bytes;
        } utf8Const;
        /**
         * @brief MethodRef type.
         * 
         * Contains the class index and name and type index.
         */
        struct {
            u2 classIndex;
            u2 nameAndTypeIndex;
        } methodRefConst;
        /**
         * @brief InterfaceMethodRef type.
         * 
         * Contains the class index and name and type index.
         */
        struct {
            u2 classIndex;
            u2 nameAndTypeIndex;
        } interfaceMethodRefConst;
        /**
         * @brief String type.
         * 
         * Contains the string index.
         */
        struct {
            u2 stringIndex;
        } stringConst;
        /**
         * @brief Inteiro type.
         * 
         * Contains the bytes.
         */
        struct {
            u4 bytes;
        } integerConst;
        /**
         * @brief Float type.
         * 
         * Contains the bytes and the value.
         */
        struct {
            union {
                u4 bytes;
                float value;
            };
        } floatConst;
        /**
         * @brief Long type.
         * 
         * Containing a sub-structure bytes, for high and low bytes, and the long type value.
         */
        struct {
            union {
                struct {
                    u4 lowBytes;
                    u4 highBytes;
                } bytes;
                long int value;
            };
        } longConst;
         /**
         * @brief Double type.
         * 
         * Containing a sub-structure bytes, for high and low bytes, and the double type value.
         */
        struct {
            union {
                struct {
                    u4 lowBytes;
                    u4 highBytes;
                } bytes;
                double value;
            };
        } doubleConst;
    };
};

/**
 * @brief ConstantPool type definition.
 * 
 * The type definition of the Constant Pool structure.
 */
typedef struct _const_pool_info ConstPoolInfo;

/**
 * @brief Attribute info structure.
 * 
 * Contains the name index, lenght, info and specific info.
 */
struct _attribute_info {
    u2 attributeNameIndex;
    u4 attributeLength;
    u1 *info;
    void *specificInfo;
};

 /**
 * @brief AttributeInfo type definition.
 * 
 * The type definition of the Attribute info structure.
 */
typedef struct _attribute_info AttributeInfo;

/**
 * @brief Field info structure.
 * 
 * Contains the acess flags, name index, descriptor index, attributtes count and a pointer type Attribute Info.
 */
struct _field_info {
    u2 accessFlags;
    u2 nameIndex;
    u2 descriptorIndex;
    u2 attributesCount;
    AttributeInfo *attributes;
};

/**
 * @brief FieldInfo type definition.
 * 
 * The type definition of the Field Info structure.
 */
typedef struct _field_info FieldInfo;

 /**
 * @brief Method info definition.
 *
 *Contains the acess flags, name index, descriptor index, attributtes count and a pointer type Attribute Info.
 */
struct _method_info {
    u2 accessFlags;
    u2 nameIndex;
    u2 descriptorIndex;
    u2 attributesCount;
    AttributeInfo *attributes;
};

/**
 * @brief MethodInfo type definition.
 * 
 * The type definition of the Method Info structure.
 */
typedef struct _method_info MethodInfo;

/**
 * @brief Constant value index definition.
 *
 * Contains the constant value index,
 */
struct _constant_value_attribute {
    u2 constantValueIndex;
};

/**
 * @brief ConstantValueAttribute type definition.
 * 
 * The type definition of the Constant Value Attribute structure.
 */
typedef struct _constant_value_attribute ConstantValueAttribute;

/**
 * @brief Exception table entry definition.
 *
 * Contains the start PC, end PC, handler PC and catch type.
 */
struct _exception_table_entry {
    u2 startPc;
    u2 endPc;
    u2 handlerPc;
    u2 catchType;
};

/**
 * @brief ExceptionTableEntry type definition.
 * 
 * The type definition of the Exception Table Entry structure.
 */
typedef struct _exception_table_entry ExceptionTableEntry;

/**
 * @brief Code Attribute definition.
 *
 * Contains the max stack, max locals, code lenght, pointer for code, exception table lenght, 
 * a pointer type ExceptionTableEntry, attribute count and a pointer type AttributeInfo.
 */
struct _code_attribute {
    u2 maxStack;
    u2 maxLocals;
    u4 codeLength;
    u1 *code;
    u2 exceptionTableLength;
    ExceptionTableEntry *exceptionTable;
    u2 attributesCount;
    AttributeInfo *attributes;
};

/**
 * @brief CodeAttribute type definition.
 * 
 * The type definition of the Attribute Code structure.
 */
typedef struct _code_attribute CodeAttribute;

/**
 * @brief Exception Attribute type.
 *
 * Contains the number of exceptions and a pointer type U2 for the exception table index.
 */
struct _exception_attribute {
    u2 numberOfExceptions;
    u2 *exceptionIndexTable;
};

/**
 * @brief ExecptionAttribute type definition.
 * 
 * The type definition of the Attribute Exception structure.
 */
typedef struct _exception_attribute ExceptionAttribute;

/**
 * @brief Inner Class definition.
 *
 * Contains the index for inner and outer class, inner name index and inner class acess flags.
 */
struct _inner_class {
    u2 innerClassInfoIndex;
    u2 outerClassInfoIndex;
    u2 innerNameIndex;
    u2 innerClassAccessFlags;
};

/**
 * @brief Inner Class type definition.
 * 
 * The type definition of the Inner Class structure.
 */
typedef struct _inner_class InnerClass;

/**
 * @brief Inner Classes Attribute definition.
 *
 * Contains the number of classes and a pointer type InnerClass.
 */
struct _inner_classes_attribute {
    u2 numberOfClasses;
    InnerClass *classes;
};

/**
 * @brief InnerClassAttribute type definition.
 * 
 * The type definition of the Inner Class Attribute structure.
 */
typedef struct _inner_classes_attribute InnerClassesAttribute;

/**
 * @brief Liner Number Table Entry definition.
 *
 * Contains the start PC and the line number.
 */
struct _line_number_table_entry {
    u2 startPc;
    u2 lineNumber;
};

/**
 * @brief LineNumberTableEntry type definition.
 * 
 * The type definition of the Line Number Table Entry structure.
 */
typedef struct _line_number_table_entry LineNumberTableEntry;

/**
 * @brief Line Number Table Attribute definition.
 *
 * Contains the line number table lenght and a pointer type LineNumberTableEntry.
 */
struct _line_number_table_attribute {
    u2 lineNumberTableLength;
    LineNumberTableEntry *lineNumberTable;
};

/**
 * @brief LineNumberTableAttribute type definition.
 * 
 * The type definition of the Line Number Table Attribute structure.
 */
typedef struct _line_number_table_attribute LineNumberTableAttribute;

/**
 * @brief Local Variable Table Entry definition.
 *
 * Contains the start PC, lenght, name and descriptor index, and the index.
 */
struct _local_variable_table_entry {
    u2 startPc;
    u2 length;
    u2 nameIndex;
    u2 descriptorIndex;
    u2 index;
};

/**
 * @brief LocalVariableTableEntry type definition.
 * 
 * The type definition of the Local Variable Table Entry structure.
 */
typedef struct _local_variable_table_entry LocalVariableTableEntry;

/**
 * @brief  Local Variable Table Attribute definition.
 *
 * Contains the local variable table lenght and a pointer type  LocalVariableTableEntry.
 */
struct _local_variable_table_attribute {
    u2 localVariableTableLength;
    LocalVariableTableEntry *localVariableTable;
};

/**
 * @brief LocalVariableTableAttribute type definition.
 * 
 * The type definition of the Local Variable Table Attribute structure.
 */
typedef struct _local_variable_table_attribute LocalVariableTableAttribute;

/**
 * @brief Source File Attribute definition.
 * 
 * Contains the source file index.
 */
struct _source_file_attribute {
    u2 sourceFileIndex;
};

/**
 * @brief SourceFileAttribute type definition.
 * 
 * The type definition of the Source File Attribute structure.
 */
typedef struct _source_file_attribute SourceFileAttribute;

/**
 * @brief Classfile definition.
 * 
 * Structure of the Classfile.
 */
struct _class {
    /**
     * @brief Magic Number.
     */
    u4 magic;
     /**
     * @brief Mejor Version.
     */
    u2 majorVersion;
    /**
     * @brief Minor Version..
     */
    u2 minorVersion;
   /**
     * @brief Counter for constant pool.
     */
    u2 constantPoolCount;
    /**
     * @brief Pointer ConstantPool type ConstantPoolInfo
     */
    ConstPoolInfo* constantPool;
   /**
     * @brief Acess Flags.
     */
    u2 accessFlags;
    /**
     * @brief This Class.
     */
    u2 thisClass;
    /**
     * @brief Super Class.
     */
    u2 superClass;
    /**
     * @brief Counter for Interfaces.
     */
    u2 interfacesCount;
    /**
     * @brief Interfaces type U2.
     */
    u2 *interfaces;
    /**
     * @brief Counter for fields.
     */
    u2 fieldsCount;
    /**
     * @brief Fields type FieldInfo.
     */
    FieldInfo *fields;
    /**
     * @brief Coounter for Métodos.
     */
    u2 methodsCount;
    /**
     * @brief Methods type MethodsInfo.
     */
    MethodInfo *methods;
    /**
     * @brief Counter of Attributes.
     */
    u2 attributesCount;
    /**
     * @brief Attributes type AttributeInfo.
     */
    AttributeInfo *attributes;
};

/**
 * @brief Class type definition.
 * 
 * The type definition of the Class structure.
 */
typedef struct _class Class;

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
Class* readClassfile(FILE* fp);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
ConstPoolInfo* readConstantPool(FILE* fp, int* offset, u2 cpCount);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u2* readInterfaces(FILE* fp, int* offset, u2 interfacesCount);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
FieldInfo * readFields(FILE* fp, int* offset, u2 fieldCount, ConstPoolInfo* constantPool);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
MethodInfo* readMethods(FILE* fp, int* offset, u2 methodsCount, ConstPoolInfo* constantPool);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
AttributeInfo* readAttributes(FILE* fp, int* offset, u2 attributesCount, ConstPoolInfo* constantPool);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
AttributeInfo* readAttributesFromByteArray(u1* info, int* offset, u2 attributesCount, ConstPoolInfo* constantPool);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
void* decodeInfo(AttributeInfo attribute, ConstPoolInfo* constantPool);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
ExceptionTableEntry* readExceptionTable(u1* info, int* offset, int exceptionTableLength);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
InnerClass* readInnerClasses(u1* info, int* offset, int numberOfClasses);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
LineNumberTableEntry* readLineNumberTable(u1* info, int* offset, int lineNumberTableLength);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
LocalVariableTableEntry* readLocalVariableTable(u1* info, int* offset, int localVariableTableLength);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
char* getUtf8FromConstantPool(int index, ConstPoolInfo* constantPool, bool isRef);
 
 /**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u1 readU1(FILE* fp, int offset);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u2 readU2(FILE* fp, int offset);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u2 readU2BigEndian(FILE* fp, int offset);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u4 readU4(FILE* fp, int offset);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u4 readU4BigEndian(FILE* fp, int offset);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u1 readU1FromByteArray(u1* byteArr, int offset);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u2 readU2FromByteArray(u1* byteArr, int offset);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u2 readU2BigEndianFromByteArray(u1* byteArr, int offset);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u4 readU4FromByteArray(u1* byteArr, int offset);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
u4 readU4BigEndianFromByteArray(u1* byteArr, int offset);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
double getDouble (u4 high, u4 low);

/**
 * @brief
 * @todo Description
 * @todo Parameters
 * @todo Return
 */
long getLong(u4 high, u4 low);

/**
 * @brief Deallocate the main elements of the .class strucure.
 * 
 * Free memory from the main elements of the .class struct. It will be
 * important to save memory for the jvm tests with many .class files.
 *
 * @params class Referece of the pointer to the .class structure.
 */
void deallocateClass(Class** class);

#endif //_CLASS_H