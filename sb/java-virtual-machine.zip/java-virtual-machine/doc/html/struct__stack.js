var struct__stack =
[
    [ "elemRef", "struct__stack.html#a0b5015ea281d723438bc3da48480054a", null ],
    [ "next", "struct__stack.html#af7121238b470563b4e74152c56529e41", null ]
];