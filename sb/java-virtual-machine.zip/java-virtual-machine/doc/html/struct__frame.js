var struct__frame =
[
    [ "codeAttribute", "struct__frame.html#a6f18ecdaabc1e847d19707a5a7ead1c5", null ],
    [ "codeIndexRef", "struct__frame.html#af923d964e8b1b0d410e54b3d44cb0deb", null ],
    [ "currentClass", "struct__frame.html#a725977e9ce15909ee07870dfa99ee5b8", null ],
    [ "localVariables", "struct__frame.html#a70eb283b830eb4912e3dc703349cc79d", null ],
    [ "operandStack", "struct__frame.html#aca830fb9d6293c1d24a87bb286f33da9", null ],
    [ "runtimeConstantPool", "struct__frame.html#ad4b473eef069cc26f7ede594362bd245", null ]
];