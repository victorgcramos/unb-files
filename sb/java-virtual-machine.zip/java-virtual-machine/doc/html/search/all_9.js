var searchData=
[
  ['jvm',['jvm',['../menu_8h.html#adaeb41806ea27039c5de1f9e5b097bcc',1,'jvm():&#160;menu.c'],['../menu_8c.html#adaeb41806ea27039c5de1f9e5b097bcc',1,'jvm():&#160;menu.c']]],
  ['jvmoption',['jvmOption',['../menu_8h.html#ae66c9abc6f7b3203a75c65c2cc53b079',1,'jvmOption(int userOption):&#160;menu.c'],['../menu_8c.html#ae66c9abc6f7b3203a75c65c2cc53b079',1,'jvmOption(int userOption):&#160;menu.c']]]
];
