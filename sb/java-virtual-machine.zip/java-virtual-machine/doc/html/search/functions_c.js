var searchData=
[
  ['newobject',['newObject',['../mem-areas_8h.html#ad2f4b4d0f16f945d876882192a519e0b',1,'mem-areas.c']]]
];
