var searchData=
[
  ['memadd',['memAdd',['../mem-manager_8h.html#a76430c75594bcbb7a25d22145f5b12f6',1,'memAdd(MemManager **managerRef, void *elemRef):&#160;mem-manager.c'],['../mem-manager_8c.html#a76430c75594bcbb7a25d22145f5b12f6',1,'memAdd(MemManager **managerRef, void *elemRef):&#160;mem-manager.c']]],
  ['memdelete',['memDelete',['../mem-manager_8h.html#a349c4b0ee2b163742221c7889e6675fb',1,'memDelete(MemManager **managerRef, void *elemRef):&#160;mem-manager.c'],['../mem-manager_8c.html#a349c4b0ee2b163742221c7889e6675fb',1,'memDelete(MemManager **managerRef, void *elemRef):&#160;mem-manager.c']]],
  ['meminit',['memInit',['../mem-manager_8h.html#ab5e1f5e11cc87cc99a770ac3b76dea81',1,'memInit(void *elemRef):&#160;mem-manager.c'],['../mem-manager_8c.html#ab5e1f5e11cc87cc99a770ac3b76dea81',1,'memInit(void *elemRef):&#160;mem-manager.c']]],
  ['menu',['menu',['../menu_8h.html#a2a0e843767aeea4f433a28b9c54f573a',1,'menu.h']]],
  ['menuoption',['menuOption',['../menu_8h.html#ade6ff3d920f2b57d1aa11da22afb9ab2',1,'menuOption(int userOption):&#160;menu.c'],['../menu_8c.html#ade6ff3d920f2b57d1aa11da22afb9ab2',1,'menuOption(int userOption):&#160;menu.c']]]
];
