var searchData=
[
  ['magic',['magic',['../struct__class.html#afcc54e09b60bb7c34819b873a9877201',1,'_class']]],
  ['majorversion',['majorVersion',['../struct__class.html#ad9cc291b36b2be5fd430be2cfb6b94c8',1,'_class']]],
  ['mem_2dareas_2eh',['mem-areas.h',['../mem-areas_8h.html',1,'']]],
  ['mem_2dmanager_2ec',['mem-manager.c',['../mem-manager_8c.html',1,'']]],
  ['mem_2dmanager_2eh',['mem-manager.h',['../mem-manager_8h.html',1,'']]],
  ['memadd',['memAdd',['../mem-manager_8h.html#a76430c75594bcbb7a25d22145f5b12f6',1,'memAdd(MemManager **managerRef, void *elemRef):&#160;mem-manager.c'],['../mem-manager_8c.html#a76430c75594bcbb7a25d22145f5b12f6',1,'memAdd(MemManager **managerRef, void *elemRef):&#160;mem-manager.c']]],
  ['memdelete',['memDelete',['../mem-manager_8h.html#a349c4b0ee2b163742221c7889e6675fb',1,'memDelete(MemManager **managerRef, void *elemRef):&#160;mem-manager.c'],['../mem-manager_8c.html#a349c4b0ee2b163742221c7889e6675fb',1,'memDelete(MemManager **managerRef, void *elemRef):&#160;mem-manager.c']]],
  ['meminit',['memInit',['../mem-manager_8h.html#ab5e1f5e11cc87cc99a770ac3b76dea81',1,'memInit(void *elemRef):&#160;mem-manager.c'],['../mem-manager_8c.html#ab5e1f5e11cc87cc99a770ac3b76dea81',1,'memInit(void *elemRef):&#160;mem-manager.c']]],
  ['memlist',['memList',['../mem-manager_8c.html#a0932b0ab84516e9a626f17cd93d24b69',1,'mem-manager.c']]],
  ['memmanager',['MemManager',['../mem-manager_8h.html#aa9dea5ff3039792cc5d7e9e0be4d0010',1,'mem-manager.h']]],
  ['menu',['menu',['../menu_8h.html#a2a0e843767aeea4f433a28b9c54f573a',1,'menu.h']]],
  ['menu_2ec',['menu.c',['../menu_8c.html',1,'']]],
  ['menu_2eh',['menu.h',['../menu_8h.html',1,'']]],
  ['menuoption',['menuOption',['../menu_8h.html#ade6ff3d920f2b57d1aa11da22afb9ab2',1,'menuOption(int userOption):&#160;menu.c'],['../menu_8c.html#ade6ff3d920f2b57d1aa11da22afb9ab2',1,'menuOption(int userOption):&#160;menu.c']]],
  ['methodinfo',['MethodInfo',['../class_8h.html#acc1d62a77f2f635f02b4c9c251fa055b',1,'class.h']]],
  ['methodrefconst',['methodRefConst',['../struct__const__pool__info.html#a4dc14ba745d6eab9a75d49245aee1a6b',1,'_const_pool_info']]],
  ['methods',['methods',['../struct__class.html#abf90e31297f373deab1a14ae324828df',1,'_class']]],
  ['methodscount',['methodsCount',['../struct__class.html#a10209ec10448d6ff3f58e3fa53db6c8c',1,'_class']]],
  ['minorversion',['minorVersion',['../struct__class.html#a5f5e57781bc92feb201b4c1241467989',1,'_class']]]
];
