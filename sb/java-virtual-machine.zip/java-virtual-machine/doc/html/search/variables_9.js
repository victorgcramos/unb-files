var searchData=
[
  ['nameandtypeconst',['nameAndTypeConst',['../struct__const__pool__info.html#ac2e61aa5c4ae2b13462b320a3e80e426',1,'_const_pool_info']]],
  ['next',['next',['../struct__mem__manager.html#a5ee37e6d974a928dbafa24fb4d78d082',1,'_mem_manager::next()'],['../struct__stack.html#af7121238b470563b4e74152c56529e41',1,'_stack::next()']]]
];
