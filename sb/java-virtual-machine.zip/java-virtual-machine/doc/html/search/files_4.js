var searchData=
[
  ['mem_2dareas_2eh',['mem-areas.h',['../mem-areas_8h.html',1,'']]],
  ['mem_2dmanager_2ec',['mem-manager.c',['../mem-manager_8c.html',1,'']]],
  ['mem_2dmanager_2eh',['mem-manager.h',['../mem-manager_8h.html',1,'']]],
  ['menu_2ec',['menu.c',['../menu_8c.html',1,'']]],
  ['menu_2eh',['menu.h',['../menu_8h.html',1,'']]]
];
