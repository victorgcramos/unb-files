var searchData=
[
  ['initclassloader',['initClassLoader',['../mem-areas_8h.html#a2c617c689f8e9fd6c5a7831eab55e521',1,'mem-areas.c']]],
  ['initframe',['initFrame',['../mem-areas_8h.html#a68e80af77c94f9d7b13aa9d2e90f29f3',1,'mem-areas.c']]],
  ['initframestack',['initFrameStack',['../mem-areas_8h.html#aaeb12aadca805d4cf632db03e23d5e13',1,'mem-areas.c']]],
  ['initheap',['initHeap',['../mem-areas_8h.html#a1a537cf8e281e61edb4f9960fa5132c2',1,'mem-areas.h']]]
];
