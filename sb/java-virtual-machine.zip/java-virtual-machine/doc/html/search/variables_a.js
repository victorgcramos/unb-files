var searchData=
[
  ['stringconst',['stringConst',['../struct__const__pool__info.html#aba6d90d3521f948a54096fcfb1e5e170',1,'_const_pool_info']]],
  ['superclass',['superClass',['../struct__class.html#a078a536be315aee3a7b6ae011f2bf8bb',1,'_class']]]
];
