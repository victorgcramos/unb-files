var searchData=
[
  ['object',['Object',['../mem-areas_8h.html#a2ea8cd593e71cb6a269d33e70c6b9f8c',1,'mem-areas.h']]]
];
