var searchData=
[
  ['userfilepath',['userfilePath',['../menu_8c.html#a8be0a10d525e2480cc8d59644f05e1f2',1,'menu.c']]],
  ['userfilepointer',['userfilePointer',['../menu_8c.html#ae10bfa98a2b0fed9c48b459c7fe42823',1,'menu.c']]],
  ['utf8const',['utf8Const',['../struct__const__pool__info.html#a0c49fe7cfce9d1e3f36c117ad6b61268',1,'_const_pool_info']]]
];
