var searchData=
[
  ['elemref',['elemRef',['../struct__mem__manager.html#a1af16e1fb8b034f70d83e962e766720f',1,'_mem_manager::elemRef()'],['../struct__stack.html#a0b5015ea281d723438bc3da48480054a',1,'_stack::elemRef()']]]
];
