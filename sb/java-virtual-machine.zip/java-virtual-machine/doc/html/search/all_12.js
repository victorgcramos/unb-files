var searchData=
[
  ['viewer',['viewer',['../menu_8h.html#a12f4b9e7acdcd1e5d916a9c3f1c513c7',1,'viewer():&#160;menu.c'],['../menu_8c.html#a12f4b9e7acdcd1e5d916a9c3f1c513c7',1,'viewer():&#160;menu.c']]],
  ['vieweroption',['viewerOption',['../menu_8h.html#afda07c975dd174518c6fdb8ec110d6c3',1,'viewerOption(int userOption):&#160;menu.c'],['../menu_8c.html#afda07c975dd174518c6fdb8ec110d6c3',1,'viewerOption(int userOption):&#160;menu.c']]]
];
