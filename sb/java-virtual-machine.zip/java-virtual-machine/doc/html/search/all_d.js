var searchData=
[
  ['object',['Object',['../mem-areas_8h.html#a2ea8cd593e71cb6a269d33e70c6b9f8c',1,'mem-areas.h']]],
  ['openfile',['openFile',['../file_8h.html#a2d8d7e2bd67885ce53b22e0e657e4359',1,'openFile(char filename[255], char *mode):&#160;file.c'],['../file_8c.html#a2d8d7e2bd67885ce53b22e0e657e4359',1,'openFile(char filename[255], char *mode):&#160;file.c']]]
];
