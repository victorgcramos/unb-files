var searchData=
[
  ['faload',['faload',['../instruction_8h.html#a97106aba181fd53454bccb90f975935e',1,'faload(Instruction *instr):&#160;instruction.c'],['../instruction_8c.html#a97106aba181fd53454bccb90f975935e',1,'faload(Instruction *instr):&#160;instruction.c']]],
  ['filesize',['fileSize',['../file_8h.html#a92a91dc6026de9f2ca4bb31e28047800',1,'fileSize(FILE *fp):&#160;file.c'],['../file_8c.html#a92a91dc6026de9f2ca4bb31e28047800',1,'fileSize(FILE *fp):&#160;file.c']]],
  ['findclassbyname',['findClassByName',['../mem-areas_8h.html#a94caaa19aeea159300d9dcd6785f11ef',1,'mem-areas.c']]],
  ['freememmanager',['freeMemManager',['../mem-manager_8h.html#a3e1d5ce2b586a8695dc143f4e3fefe6d',1,'freeMemManager():&#160;mem-manager.c'],['../mem-manager_8c.html#a3e1d5ce2b586a8695dc143f4e3fefe6d',1,'freeMemManager():&#160;mem-manager.c']]]
];
