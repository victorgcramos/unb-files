var searchData=
[
  ['utf8tostring',['utf8ToString',['../convert_8h.html#a340aa7bc29cca98a34bfbb78d48a42d9',1,'utf8ToString(uint8_t *src, uint16_t length, bool isRef):&#160;convert.c'],['../convert_8c.html#a340aa7bc29cca98a34bfbb78d48a42d9',1,'utf8ToString(uint8_t *src, uint16_t length, bool isRef):&#160;convert.c']]]
];
