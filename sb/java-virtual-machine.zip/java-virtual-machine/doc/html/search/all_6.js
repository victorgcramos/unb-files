var searchData=
[
  ['faload',['faload',['../instruction_8h.html#a97106aba181fd53454bccb90f975935e',1,'faload(Instruction *instr):&#160;instruction.c'],['../instruction_8c.html#a97106aba181fd53454bccb90f975935e',1,'faload(Instruction *instr):&#160;instruction.c']]],
  ['fieldinfo',['FieldInfo',['../class_8h.html#aeeee47e842f08ed8286ca9e783ce6de9',1,'class.h']]],
  ['fieldrefconst',['fieldRefConst',['../struct__const__pool__info.html#a8dfd4f72d9480e247c50253a87825b4b',1,'_const_pool_info']]],
  ['fields',['fields',['../struct__class.html#afdd0223f54ad9f24370fa49ebc98584c',1,'_class']]],
  ['fieldscount',['fieldsCount',['../struct__class.html#a5589c7f5e60f8d6d968f811a6ccfad8a',1,'_class']]],
  ['file_2ec',['file.c',['../file_8c.html',1,'']]],
  ['file_2eh',['file.h',['../file_8h.html',1,'']]],
  ['filesize',['fileSize',['../file_8h.html#a92a91dc6026de9f2ca4bb31e28047800',1,'fileSize(FILE *fp):&#160;file.c'],['../file_8c.html#a92a91dc6026de9f2ca4bb31e28047800',1,'fileSize(FILE *fp):&#160;file.c']]],
  ['findclassbyname',['findClassByName',['../mem-areas_8h.html#a94caaa19aeea159300d9dcd6785f11ef',1,'mem-areas.c']]],
  ['floatconst',['floatConst',['../struct__const__pool__info.html#ab2e373f9f716d020067b54aee56c7069',1,'_const_pool_info']]],
  ['forever',['forever',['../common_8h.html#a8c25998f80abf59bbbc3fd3011d8bba6',1,'common.h']]],
  ['frame',['Frame',['../mem-areas_8h.html#a9ad3692f5f0723287eb5e1b5ed414361',1,'mem-areas.h']]],
  ['freememmanager',['freeMemManager',['../mem-manager_8h.html#a3e1d5ce2b586a8695dc143f4e3fefe6d',1,'freeMemManager():&#160;mem-manager.c'],['../mem-manager_8c.html#a3e1d5ce2b586a8695dc143f4e3fefe6d',1,'freeMemManager():&#160;mem-manager.c']]]
];
