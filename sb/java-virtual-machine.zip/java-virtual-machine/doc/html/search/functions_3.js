var searchData=
[
  ['choosefile',['chooseFile',['../menu_8h.html#ae42823dd6adebec37238d78b31464ffc',1,'chooseFile():&#160;menu.c'],['../menu_8c.html#ae42823dd6adebec37238d78b31464ffc',1,'chooseFile():&#160;menu.c']]],
  ['clearscreen',['clearScreen',['../menu_8h.html#a9d7e8af417b6d543da691e9c0e2f6f9f',1,'clearScreen():&#160;menu.c'],['../menu_8c.html#a9d7e8af417b6d543da691e9c0e2f6f9f',1,'clearScreen():&#160;menu.c']]],
  ['closefile',['closeFile',['../file_8h.html#a72324deb36a0345d8c7e83c1451c1fe2',1,'closeFile(FILE **):&#160;file.c'],['../file_8c.html#a21c0eecd553c1c274c0414717ebaf9e4',1,'closeFile(FILE **fp):&#160;file.c']]]
];
