var searchData=
[
  ['allocate',['allocate',['../mem-manager_8h.html#ac00c82aaab0c1ab74dd1fa304be34bff',1,'allocate(size_t memorySpace):&#160;mem-manager.c'],['../mem-manager_8c.html#ac00c82aaab0c1ab74dd1fa304be34bff',1,'allocate(size_t memorySpace):&#160;mem-manager.c']]]
];
