var searchData=
[
  ['laload',['laload',['../instruction_8h.html#a107e80b2ba6fb336ec6b9f28870e735d',1,'laload(Instruction *instr):&#160;instruction.c'],['../instruction_8c.html#a107e80b2ba6fb336ec6b9f28870e735d',1,'laload(Instruction *instr):&#160;instruction.c']]]
];
