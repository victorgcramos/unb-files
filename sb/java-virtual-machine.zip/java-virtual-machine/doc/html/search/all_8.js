var searchData=
[
  ['initclassloader',['initClassLoader',['../mem-areas_8h.html#a2c617c689f8e9fd6c5a7831eab55e521',1,'mem-areas.c']]],
  ['initframe',['initFrame',['../mem-areas_8h.html#a68e80af77c94f9d7b13aa9d2e90f29f3',1,'mem-areas.c']]],
  ['initframestack',['initFrameStack',['../mem-areas_8h.html#aaeb12aadca805d4cf632db03e23d5e13',1,'mem-areas.c']]],
  ['initheap',['initHeap',['../mem-areas_8h.html#a1a537cf8e281e61edb4f9960fa5132c2',1,'mem-areas.h']]],
  ['innerclass',['InnerClass',['../class_8h.html#a6b2bc77443d5214c39698de6905a4786',1,'class.h']]],
  ['innerclassesattribute',['InnerClassesAttribute',['../class_8h.html#a9dd9182734e38f67f09a471fed935f84',1,'class.h']]],
  ['instruction',['Instruction',['../instruction_8h.html#a46f2e1daa13587f1b0c73a8245e5e371',1,'instruction.h']]],
  ['instruction_2ec',['instruction.c',['../instruction_8c.html',1,'']]],
  ['instruction_2eh',['instruction.h',['../instruction_8h.html',1,'']]],
  ['instructionsarea',['InstructionsArea',['../mem-areas_8h.html#afbf86d68f90b34360a1d4968d5f073e1',1,'mem-areas.h']]],
  ['integerconst',['integerConst',['../struct__const__pool__info.html#af50043a1dd93ebe98c358ff5130e0b94',1,'_const_pool_info']]],
  ['interfacemethodrefconst',['interfaceMethodRefConst',['../struct__const__pool__info.html#a51e4947ac5606243cdb8e809e5b91298',1,'_const_pool_info']]],
  ['interfaces',['interfaces',['../struct__class.html#a65c4b8ab27325be7361133c38b3cf0d6',1,'_class']]],
  ['interfacescount',['interfacesCount',['../struct__class.html#ac6f74b02d5c5e7cde7ce950625f3a4b5',1,'_class']]]
];
