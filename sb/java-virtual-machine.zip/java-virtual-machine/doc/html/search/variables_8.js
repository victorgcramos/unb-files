var searchData=
[
  ['magic',['magic',['../struct__class.html#afcc54e09b60bb7c34819b873a9877201',1,'_class']]],
  ['majorversion',['majorVersion',['../struct__class.html#ad9cc291b36b2be5fd430be2cfb6b94c8',1,'_class']]],
  ['memlist',['memList',['../mem-manager_8c.html#a0932b0ab84516e9a626f17cd93d24b69',1,'mem-manager.c']]],
  ['methodrefconst',['methodRefConst',['../struct__const__pool__info.html#a4dc14ba745d6eab9a75d49245aee1a6b',1,'_const_pool_info']]],
  ['methods',['methods',['../struct__class.html#abf90e31297f373deab1a14ae324828df',1,'_class']]],
  ['methodscount',['methodsCount',['../struct__class.html#a10209ec10448d6ff3f58e3fa53db6c8c',1,'_class']]],
  ['minorversion',['minorVersion',['../struct__class.html#a5f5e57781bc92feb201b4c1241467989',1,'_class']]]
];
