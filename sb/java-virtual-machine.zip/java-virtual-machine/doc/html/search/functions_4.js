var searchData=
[
  ['daload',['daload',['../instruction_8c.html#a650d50fd545fe189afd1d39391edcacb',1,'instruction.c']]],
  ['deallocate',['deallocate',['../mem-manager_8h.html#abfedbedfa3c0060bc8101d56a9b16f75',1,'deallocate(void **pointer):&#160;mem-manager.c'],['../mem-manager_8c.html#abfedbedfa3c0060bc8101d56a9b16f75',1,'deallocate(void **pointer):&#160;mem-manager.c']]],
  ['deallocateclass',['deallocateClass',['../class_8h.html#a6515dc36310471c59a60062f8be4b36e',1,'deallocateClass(Class **class):&#160;class.c'],['../class_8c.html#a6515dc36310471c59a60062f8be4b36e',1,'deallocateClass(Class **class):&#160;class.c']]],
  ['decode',['decode',['../execute_8h.html#a35fb108bcd15263c2774c3a8c70ecb2c',1,'decode(u1 *byteCode, int *offset):&#160;execute.c'],['../execute_8c.html#a09ed09f16a02003f49fb2eaf422a05af',1,'decode(u1 *bytecode, int *offset):&#160;execute.c']]],
  ['decodeinfo',['decodeInfo',['../class_8h.html#ae0736c015948eab14d587f1baf829917',1,'decodeInfo(AttributeInfo attribute, ConstPoolInfo *constantPool):&#160;class.c'],['../class_8c.html#ae0736c015948eab14d587f1baf829917',1,'decodeInfo(AttributeInfo attribute, ConstPoolInfo *constantPool):&#160;class.c']]]
];
