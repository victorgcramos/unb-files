var unionattr =
[
    [ "code", "unionattr.html#a7ce6b825a954d6b3fc03a257c3073139", null ],
    [ "constan", "unionattr.html#afcaff0ffee1e0bec42c477100852e352", null ],
    [ "exceptions", "unionattr.html#a2533fbcea195ca7763456d8f4f6e4a63", null ],
    [ "info", "unionattr.html#a39531483d4ac892e690f82181083da5b", null ],
    [ "source", "unionattr.html#a8a25930d9da890ce93ef7fd8473580ff", null ]
];