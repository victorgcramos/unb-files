var struct__object =
[
    [ "class", "struct__object.html#a132cd96faf239ddc2d5c444fdc53dcee", null ],
    [ "runtimeConstantPool", "struct__object.html#a2c847770e18157a1ee14bda4a43a6aa3", null ]
];