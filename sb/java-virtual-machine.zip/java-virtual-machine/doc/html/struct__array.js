var struct__array =
[
    [ "elementSize", "struct__array.html#aad0cb847d6fa2b05330e3df6b6bf3604", null ],
    [ "size", "struct__array.html#a71b5939a432386c9c981b75bb2d0eef3", null ],
    [ "type", "struct__array.html#a2c5d21d97deed3a0a35028be6c449c95", null ],
    [ "values", "struct__array.html#aee65dcd3722d47bd71eee2640d670ee3", null ]
];