var structsource__file =
[
    [ "attribute_length", "structsource__file.html#a994a11adc015c52986d5cd6cde289505", null ],
    [ "attribute_name_index", "structsource__file.html#a5e530a1b2fa7986c43ace790ccf4d7ce", null ],
    [ "sourcefile_index", "structsource__file.html#a04490aa4ce7d9c4cb47ec3b7e0665050", null ]
];