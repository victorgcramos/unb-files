var mem_manager_8c =
[
    [ "allocate", "mem-manager_8c.html#ac00c82aaab0c1ab74dd1fa304be34bff", null ],
    [ "deallocate", "mem-manager_8c.html#abfedbedfa3c0060bc8101d56a9b16f75", null ],
    [ "freeMemManager", "mem-manager_8c.html#a3e1d5ce2b586a8695dc143f4e3fefe6d", null ],
    [ "memAdd", "mem-manager_8c.html#a76430c75594bcbb7a25d22145f5b12f6", null ],
    [ "memDelete", "mem-manager_8c.html#a349c4b0ee2b163742221c7889e6675fb", null ],
    [ "memInit", "mem-manager_8c.html#ab5e1f5e11cc87cc99a770ac3b76dea81", null ],
    [ "memList", "mem-manager_8c.html#a0932b0ab84516e9a626f17cd93d24b69", null ]
];