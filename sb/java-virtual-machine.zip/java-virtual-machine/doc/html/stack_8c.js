var stack_8c =
[
    [ "stkDelete", "stack_8c.html#a6b930f9a5eb856d39706e6d552b6b316", null ],
    [ "stkHead", "stack_8c.html#adaee5421e0aea6d4d4f5e45df4951642", null ],
    [ "stkInit", "stack_8c.html#a661d22a65b63c0947ca9515319974cbb", null ],
    [ "stkPop", "stack_8c.html#a3cec0cab31e0f4d4d94cf36b7892a276", null ],
    [ "stkPush", "stack_8c.html#af33ccd683876ddb357c9f0af9f7c221f", null ]
];