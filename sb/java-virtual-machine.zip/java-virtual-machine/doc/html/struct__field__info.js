var struct__field__info =
[
    [ "accessFlags", "struct__field__info.html#a60ce83ec6b2211efb5f0a1d7508c11bd", null ],
    [ "attributes", "struct__field__info.html#adba5f4a189cd21931638d08dfbb34c13", null ],
    [ "attributesCount", "struct__field__info.html#a0ae93e8b2d74cd41ff01536cb9578662", null ],
    [ "descriptorIndex", "struct__field__info.html#adf9c41253d3580249191d868f799974c", null ],
    [ "nameIndex", "struct__field__info.html#a4245aa9e9a1c188d36ccfb157046eea3", null ]
];