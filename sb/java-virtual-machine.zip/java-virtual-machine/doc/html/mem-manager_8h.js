var mem_manager_8h =
[
    [ "_mem_manager", "struct__mem__manager.html", "struct__mem__manager" ],
    [ "MemManager", "mem-manager_8h.html#aa9dea5ff3039792cc5d7e9e0be4d0010", null ],
    [ "allocate", "mem-manager_8h.html#ac00c82aaab0c1ab74dd1fa304be34bff", null ],
    [ "deallocate", "mem-manager_8h.html#abfedbedfa3c0060bc8101d56a9b16f75", null ],
    [ "freeMemManager", "mem-manager_8h.html#a3e1d5ce2b586a8695dc143f4e3fefe6d", null ],
    [ "memAdd", "mem-manager_8h.html#a76430c75594bcbb7a25d22145f5b12f6", null ],
    [ "memDelete", "mem-manager_8h.html#a349c4b0ee2b163742221c7889e6675fb", null ],
    [ "memInit", "mem-manager_8h.html#ab5e1f5e11cc87cc99a770ac3b76dea81", null ]
];