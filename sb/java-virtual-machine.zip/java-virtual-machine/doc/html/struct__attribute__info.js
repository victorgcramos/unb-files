var struct__attribute__info =
[
    [ "attributeLength", "struct__attribute__info.html#a8c6ad4f2166630284325d1566b21f881", null ],
    [ "attributeNameIndex", "struct__attribute__info.html#a8b11179ce3bcc9688da131b313e95b47", null ],
    [ "info", "struct__attribute__info.html#a33fae861cd9129831522979fbd2d278e", null ],
    [ "specificInfo", "struct__attribute__info.html#a8a353a532c0916d84530c20f8afe539d", null ]
];