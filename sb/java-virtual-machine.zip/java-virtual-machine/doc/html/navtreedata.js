var NAVTREE =
[
  [ "Java Virtual Machine", "index.html", [
    [ "Todo List", "todo.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"instruction_8c.html#a4e5f23f51c109dbe17bae2e64c416b15",
"instruction_8h.html#a39fca1837c5ce7715cbf571669660c13a45007e5a863799315dcad6c3e28a800a",
"instruction_8h.html#ae3d64a1b9a282c7b088b8c1ddf365cc4",
"struct__method__info.html#a83a4f54573645488f30412ea1de1b661"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';