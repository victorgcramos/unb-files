var stack_8h =
[
    [ "_stack", "struct__stack.html", "struct__stack" ],
    [ "Stack", "stack_8h.html#a4f8ca44fe47426019019264d8168b32c", null ],
    [ "stkDelete", "stack_8h.html#a6b930f9a5eb856d39706e6d552b6b316", null ],
    [ "stkHead", "stack_8h.html#adaee5421e0aea6d4d4f5e45df4951642", null ],
    [ "stkInit", "stack_8h.html#a661d22a65b63c0947ca9515319974cbb", null ],
    [ "stkPop", "stack_8h.html#a3cec0cab31e0f4d4d94cf36b7892a276", null ],
    [ "stkPush", "stack_8h.html#af33ccd683876ddb357c9f0af9f7c221f", null ]
];