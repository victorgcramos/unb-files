var struct__instruction =
[
    [ "arguments", "struct__instruction.html#a8c6c3795756bcf1408d6e4eb8d21180d", null ],
    [ "argumentsCount", "struct__instruction.html#ab07822c1c7ee55ffc141613026799429", null ],
    [ "execute", "struct__instruction.html#abe72e303462f0d5ee793608e0bbb272c", null ],
    [ "name", "struct__instruction.html#aa044af13c76a741decf1dbc5bf319935", null ],
    [ "opcode", "struct__instruction.html#a5fa32fb6b44697df54081c62e13f4229", null ],
    [ "pc", "struct__instruction.html#a32aad41d8240b8fc6ac7e488d850204a", null ]
];