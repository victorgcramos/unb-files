var struct__inner__class =
[
    [ "innerClassAccessFlags", "struct__inner__class.html#a99463e545910302a667ef5c6f941699d", null ],
    [ "innerClassInfoIndex", "struct__inner__class.html#a7cbb43ac2dc0b573cf4f853058e40d61", null ],
    [ "innerNameIndex", "struct__inner__class.html#a39a461dbd5a786e9c17cc39df277047e", null ],
    [ "outerClassInfoIndex", "struct__inner__class.html#abb42f75dd8f08d42b41a6b231017a49b", null ]
];