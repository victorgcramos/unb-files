var struct__exception__attribute =
[
    [ "exceptionIndexTable", "struct__exception__attribute.html#a8d56ded7b7b608e5473456563979d5fe", null ],
    [ "numberOfExceptions", "struct__exception__attribute.html#af1ba53b5301110c44eeeb6fa6061dbc3", null ]
];