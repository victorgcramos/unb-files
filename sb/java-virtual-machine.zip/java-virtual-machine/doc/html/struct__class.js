var struct__class =
[
    [ "accessFlags", "struct__class.html#ac8e70e2754cf920c2e3b04253dc03d96", null ],
    [ "attributes", "struct__class.html#a9644bc97985419f5073f5736e9892c8d", null ],
    [ "attributesCount", "struct__class.html#a12d3e416b8eacaa717117ffcfd63dc03", null ],
    [ "constantPool", "struct__class.html#a9a122f1488b1023a4e41f4a6bdcaf470", null ],
    [ "constantPoolCount", "struct__class.html#aab9ff1bd978b7a04c46757abfa8f2c92", null ],
    [ "fields", "struct__class.html#afdd0223f54ad9f24370fa49ebc98584c", null ],
    [ "fieldsCount", "struct__class.html#a5589c7f5e60f8d6d968f811a6ccfad8a", null ],
    [ "interfaces", "struct__class.html#a65c4b8ab27325be7361133c38b3cf0d6", null ],
    [ "interfacesCount", "struct__class.html#ac6f74b02d5c5e7cde7ce950625f3a4b5", null ],
    [ "magic", "struct__class.html#afcc54e09b60bb7c34819b873a9877201", null ],
    [ "majorVersion", "struct__class.html#ad9cc291b36b2be5fd430be2cfb6b94c8", null ],
    [ "methods", "struct__class.html#abf90e31297f373deab1a14ae324828df", null ],
    [ "methodsCount", "struct__class.html#a10209ec10448d6ff3f58e3fa53db6c8c", null ],
    [ "minorVersion", "struct__class.html#a5f5e57781bc92feb201b4c1241467989", null ],
    [ "superClass", "struct__class.html#a078a536be315aee3a7b6ae011f2bf8bb", null ],
    [ "thisClass", "struct__class.html#a5d2b0868b5d397e014e4b4044cdd9036", null ]
];