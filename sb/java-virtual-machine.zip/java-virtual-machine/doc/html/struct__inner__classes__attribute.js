var struct__inner__classes__attribute =
[
    [ "classes", "struct__inner__classes__attribute.html#ac288818b68951fc0f3b95c833ca704c7", null ],
    [ "numberOfClasses", "struct__inner__classes__attribute.html#a4cdc6f2fddfedb28b2d6b607ac686fdd", null ]
];