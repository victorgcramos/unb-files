var struct__mem__manager =
[
    [ "elemRef", "struct__mem__manager.html#a1af16e1fb8b034f70d83e962e766720f", null ],
    [ "next", "struct__mem__manager.html#a5ee37e6d974a928dbafa24fb4d78d082", null ]
];