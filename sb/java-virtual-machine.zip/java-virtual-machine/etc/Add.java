public class Add {

    public static void main(String[] args) {
        int[] f = new int[3];
        for (int i=0;i<3;i++) {
        	f[i] = i;
        }
        for (int i=0;i<3;i++) {
        	System.out.println(f[i]);
        }
    }
}