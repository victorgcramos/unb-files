public interface Interfaces {
    public int privateInt = 10;
    public String HelloWorld();
}