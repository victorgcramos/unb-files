public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Vamos! Vamos Cruzeiro!\nVamos! Vamos pra ganhar!\nVou aonde voce for!\nSo pra ver voce jogar!");
    }
}