public class Implements implements Interfaces {

    public static void main(String[] args) {
        System.out.println(new Implements().HelloWorld());
    }

    public String HelloWorld() {
        return "Hello World!";
    }
}